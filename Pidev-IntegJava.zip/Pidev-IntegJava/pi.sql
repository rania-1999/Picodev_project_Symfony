-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 13 avr. 2021 à 16:40
-- Version du serveur :  8.0.21
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pi`
--

-- --------------------------------------------------------

--
-- Structure de la table `amis`
--

DROP TABLE IF EXISTS `amis`;
CREATE TABLE IF NOT EXISTS `amis` (
  `FriendshipID` int NOT NULL AUTO_INCREMENT,
  `IDUser` int NOT NULL,
  `FriendID` int NOT NULL,
  `Confirmed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`FriendshipID`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `amis`
--

INSERT INTO `amis` (`FriendshipID`, `IDUser`, `FriendID`, `Confirmed`) VALUES
(20, 13, 10, 1),
(21, 10, 13, 1),
(22, 31, 10, 0),
(23, 38, 10, 1),
(24, 10, 38, 1);

-- --------------------------------------------------------

--
-- Structure de la table `arbitre`
--

DROP TABLE IF EXISTS `arbitre`;
CREATE TABLE IF NOT EXISTS `arbitre` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `filiere` varchar(20) NOT NULL,
  `image` varchar(250) NOT NULL,
  `disponibilite` varchar(20) NOT NULL,
  `date_arbitre` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `arbitre`
--

INSERT INTO `arbitre` (`id`, `nom`, `prenom`, `filiere`, `image`, `disponibilite`, `date_arbitre`) VALUES
(1, 'rrrf', 'ergn', 'erg', 'C:\\wamp64\\www\\PiJava\\4th.png', '', '2021-03-17'),
(2, 'bbbvg', 'ergrtbet', 'ergrtb', 'C:\\wamp64\\www\\PiJava\\4th.png', '', '2021-03-10'),
(16, 'try', 'ryh', 'tut', 'C:\\wamp64\\www\\PiJava\\4th.png', '', '2021-03-17'),
(31, 'try', 'ryh', 'tut', 'C:\\wamp64\\www\\PiJava\\4th.png', 'null', '2021-03-03'),
(37, 'w', 'a', 'foot', 'C:wamp64wwwPiJava2nd.png', 'null', '2021-04-14'),
(38, 'b', 'c', 'hand', 'C:\\wamp64\\www\\PiJava\\ArbitreIcon.png', 'null', '2021-04-14'),
(39, 'ac', 'wz', 'foot', 'C:\\wamp64\\www\\PiJava\\ArbitreIcon.png', 'null', '2021-04-14'),
(40, 'ac', 'wz', 'foot', 'C:wamp64wwwPiJavaArbitreIcon.png', 'null', '2021-04-23');

-- --------------------------------------------------------

--
-- Structure de la table `coach`
--

DROP TABLE IF EXISTS `coach`;
CREATE TABLE IF NOT EXISTS `coach` (
  `IDC` int NOT NULL AUTO_INCREMENT,
  `IDUser` int NOT NULL,
  `Filiere` varchar(255) NOT NULL,
  `AnExp` int NOT NULL,
  `Region` varchar(255) NOT NULL,
  `Proof` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Confirmed` int DEFAULT '0',
  PRIMARY KEY (`IDC`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `coach`
--

INSERT INTO `coach` (`IDC`, `IDUser`, `Filiere`, `AnExp`, `Region`, `Proof`, `Confirmed`) VALUES
(14, 13, 'football', 10, 'tunis', 'http://localhost/PiJava/TerrainIcon.png', 0),
(15, 39, 'hand', 10, 'tunis', 'http://localhost/PiJava/1st.png', 1);

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `idCommentaire` int NOT NULL AUTO_INCREMENT,
  `Contenu` text NOT NULL,
  `dateCommentaire` date NOT NULL,
  `idNews` int NOT NULL,
  `idUtilisateur` int NOT NULL,
  PRIMARY KEY (`idCommentaire`),
  KEY `idNews` (`idNews`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`idCommentaire`, `Contenu`, `dateCommentaire`, `idNews`, `idUtilisateur`) VALUES
(131, 'aaa', '2021-04-02', 82, 0),
(133, 'Amine\nss', '2021-04-02', 82, 10),
(134, 'Amineesprit\nso excited!', '2021-04-02', 86, 13),
(135, 'Amineesprit\nxxx', '2021-04-02', 85, 13),
(136, 'Amineesprit\nshit aa', '2021-04-02', 85, 13);

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

DROP TABLE IF EXISTS `evenement`;
CREATE TABLE IF NOT EXISTS `evenement` (
  `id_evenement` int NOT NULL AUTO_INCREMENT,
  `nom_evenement` varchar(2100) NOT NULL,
  `descrip_evenement` varchar(3000) NOT NULL,
  `date_evenement` date NOT NULL,
  PRIMARY KEY (`id_evenement`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `evenement`
--

INSERT INTO `evenement` (`id_evenement`, `nom_evenement`, `descrip_evenement`, `date_evenement`) VALUES
(1, 'dfhf', 'fhfy', '2021-03-09'),
(36, 'cvc', 'fgfd', '2021-03-17'),
(37, 'hf', 'fhgf', '2021-03-12'),
(38, 'dffg', 'fgd', '2021-03-10'),
(39, 'dsd', 'fdsfd', '2021-03-09'),
(40, 'dsd', 'fdsfd', '2021-03-09'),
(41, 'df', 'dfs', '2021-03-09'),
(42, 'fvrf', 'rg', '2021-03-09'),
(43, 'qdf', 'dfgd', '2021-03-11'),
(44, 'hf', 'fhgf', '2021-03-11'),
(45, 'ze', 'df', '2021-03-09'),
(46, 'dezedsr', 'zer', '2021-03-10'),
(47, 'qf', 'dsf', '2021-03-09'),
(48, 'xbx', 'fhfh', '2021-03-09'),
(49, 'dfsf', 'sdfdf', '2021-03-12'),
(50, 'dfhf', 'fhfy', '2021-03-10'),
(51, 'dfhf', 'fhfy', '2021-03-03'),
(52, 'match foot', 'realbarca', '2021-04-07');

-- --------------------------------------------------------

--
-- Structure de la table `gestion`
--

DROP TABLE IF EXISTS `gestion`;
CREATE TABLE IF NOT EXISTS `gestion` (
  `idu` int NOT NULL,
  `ide` int NOT NULL,
  `ida` int NOT NULL,
  `idm` int NOT NULL,
  `idp` int NOT NULL,
  KEY `idu` (`idu`),
  KEY `ide` (`ide`,`ida`,`idm`),
  KEY `idp` (`idp`),
  KEY `ida` (`ida`),
  KEY `idm` (`idm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gestion`
--

INSERT INTO `gestion` (`idu`, `ide`, `ida`, `idm`, `idp`) VALUES
(10, 1, 1, 1, 16),
(10, 1, 1, 1, 16),
(13, 1, 1, 1, 16),
(13, 1, 1, 1, 16),
(35, 46, 16, 1, 25),
(35, 46, 16, 1, 25),
(35, 46, 16, 1, 25);

-- --------------------------------------------------------

--
-- Structure de la table `match`
--

DROP TABLE IF EXISTS `match`;
CREATE TABLE IF NOT EXISTS `match` (
  `id_m` int NOT NULL AUTO_INCREMENT,
  `equipeA` varchar(30) NOT NULL,
  `equipeB` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `tour` varchar(30) NOT NULL,
  `image` varchar(250) NOT NULL,
  PRIMARY KEY (`id_m`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `match`
--

INSERT INTO `match` (`id_m`, `equipeA`, `equipeB`, `date`, `tour`, `image`) VALUES
(1, 'sdf', 'sfdsd', '2021-03-09', 'sdfdfj', 'C:\\wamp64\\www\\PiJava\\4th.png'),
(2, 'sdf', 'sfdsd', '2021-03-10', 'sdfdf', 'C:\\wamp64\\www\\PiJava\\4th.png'),
(3, 'sdf', 'sfdsd', '2021-03-19', 'sdfdf', 'C:\\wamp64\\www\\PiJava\\4th.png'),
(4, 'sdf', 'sfdsd', '2021-03-10', 'mmmmmmm', 'C:\\wamp64\\www\\PiJava\\4th.png'),
(47, 'ff', 'ss', '2021-04-14', 'ww', 'C:\\wamp64\\www\\PiJava\\2nd.png'),
(48, 'abc', 'dfe', '2021-04-06', 'tun', 'C:\\wamp64\\www\\PiJava\\2nd.png'),
(49, 'barca', 'real', '2021-04-13', 'cl', 'C:wamp64wwwPiJava2nd.png');

-- --------------------------------------------------------

--
-- Structure de la table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Contenu` text NOT NULL,
  `Titre` text NOT NULL,
  `ImageNews` varchar(255) DEFAULT NULL,
  `Date` date NOT NULL,
  `TypeSport` varchar(255) DEFAULT NULL,
  `nbreacts` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `news`
--

INSERT INTO `news` (`id`, `Contenu`, `Titre`, `ImageNews`, `Date`, `TypeSport`, `nbreacts`) VALUES
(82, 'sdc', 'fdc', 'http://localhost/pijava/CoachIcon.png', '2021-04-02', 'BASEBALL', 0),
(83, 'un nouveau match bientot ', 'match', 'http://localhost/pijava/bluelock.png', '2021-04-02', 'BASEBALL', 0),
(84, 'bbbb', 'aa', 'http://localhost/pijava/ArbitreIcon.png', '2021-04-02', 'FOOTBALL', 0),
(85, 'cont', 'test', 'http://localhost/pijava/DecoTXT.png', '2021-04-02', 'FOOTBALL', 0),
(86, 'N\'oubliez pas le classico le samedi 10 avril ', 'match classico dans 8 jours', 'http://localhost/pijava/DecoTXT.png', '2021-04-02', 'FOOTBALL', 1);

-- --------------------------------------------------------

--
-- Structure de la table `participant`
--

DROP TABLE IF EXISTS `participant`;
CREATE TABLE IF NOT EXISTS `participant` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `participant`
--

INSERT INTO `participant` (`id`, `nom`, `prenom`) VALUES
(16, 'kkkk', 'kkkkk'),
(18, 'hhh', 'hhhjk'),
(24, 'yghj', 'jhkl'),
(25, 'ezhf', 'ere'),
(26, '', ''),
(27, 'hkjl', 'hkjl'),
(28, 'hkjlk', 'ytuyiul'),
(29, 'srfref', 'rtefd'),
(30, 'lkzde', 'ezrzer'),
(31, 'effd', 'dfd'),
(32, 'effd', 'dfd'),
(33, 'rfcdc', 'rfee'),
(34, 'sdvc', 'fdc'),
(35, 'efdf', 'fdv'),
(36, 'rez', 'rgr'),
(37, 'rgt', 'rgt'),
(38, 'gfdhg', 'gfh'),
(39, 'gfh', 'hnn'),
(40, 'srf', 'fbfb'),
(41, 'fgg', 'greg'),
(42, 'fefg', 'gf'),
(43, 'fdgf', 'gfgh'),
(44, 'fgf', 'gfb'),
(45, 'fsg', 'gfgh'),
(46, 'gfb', 'bgfb'),
(47, 'gh', 'hg'),
(48, 'fgg', 'ghgh'),
(49, 'gf', 'gf'),
(50, 'fgh', 'fgh'),
(51, 'fgh', 'fgh'),
(52, 'fh', 'hgj'),
(53, 'try', 'rty'),
(54, 'fg', 'fg'),
(55, 'fh', 'hgj'),
(56, 'mlaouah', 'bechir'),
(57, 'achour', 'amine'),
(58, 'Achour', 'Amine');

-- --------------------------------------------------------

--
-- Structure de la table `qrcode`
--

DROP TABLE IF EXISTS `qrcode`;
CREATE TABLE IF NOT EXISTS `qrcode` (
  `idQ` int NOT NULL AUTO_INCREMENT,
  `qrcodeS` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `id_p` int NOT NULL,
  `id_e` int NOT NULL,
  PRIMARY KEY (`idQ`),
  KEY `id_p` (`id_p`),
  KEY `id_e` (`id_e`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `qrcode`
--

INSERT INTO `qrcode` (`idQ`, `qrcodeS`, `img`, `id_p`, `id_e`) VALUES
(1, 'HGJJ54545', 'C:\\wamp64\\www\\PiJava\\4th.png', 18, 1),
(20, 'HGJJ545455', 'C:\\wamp64\\www\\PiJava\\4th.png', 16, 1);

-- --------------------------------------------------------

--
-- Structure de la table `reclamation`
--

DROP TABLE IF EXISTS `reclamation`;
CREATE TABLE IF NOT EXISTS `reclamation` (
  `IDRec` int NOT NULL AUTO_INCREMENT,
  `IDUser` int NOT NULL,
  `UserRec` varchar(255) NOT NULL,
  `Objet` varchar(255) NOT NULL,
  `Message` varchar(2555) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `DateAjout` date NOT NULL,
  PRIMARY KEY (`IDRec`),
  KEY `IDUser` (`IDUser`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reclamation`
--

INSERT INTO `reclamation` (`IDRec`, `IDUser`, `UserRec`, `Objet`, `Message`, `Image`, `DateAjout`) VALUES
(33, 13, 'Amineesprit', 'Test', 'testmsg', 'http://localhost/PiJava/DecoTXT.png', '2021-04-02');

-- --------------------------------------------------------

--
-- Structure de la table `terrain`
--

DROP TABLE IF EXISTS `terrain`;
CREATE TABLE IF NOT EXISTS `terrain` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomT` varchar(255) NOT NULL,
  `Adresse` varchar(255) NOT NULL,
  `type_sport` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `NumTel` int NOT NULL,
  `ressources` varchar(255) NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `terrain`
--

INSERT INTO `terrain` (`id`, `nomT`, `Adresse`, `type_sport`, `Image`, `NumTel`, `ressources`, `count`) VALUES
(1, 'Stade menzah', 'menzah1', 'FOOTBALL', 'http://localhost/PiJava/CoachIcon.png', 12314578, 'null', 0),
(5, 'Stade 15 OCT', 'Bizerte', 'FOOTBALL', 'http://localhost/PiJava/GymIcon.png', 12314578, 'null', 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Nom` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `Sexe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `NumTel` int NOT NULL,
  `DateCreation` date DEFAULT NULL,
  `Auth` int DEFAULT NULL,
  `Code` int DEFAULT NULL,
  `Image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'http://localhost/PiJava/UserIcon.png',
  `notif` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UserUN` (`Username`),
  UNIQUE KEY `EmailUN` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID`, `Username`, `Password`, `Email`, `Nom`, `Age`, `Sexe`, `NumTel`, `DateCreation`, `Auth`, `Code`, `Image`, `notif`) VALUES
(10, 'Amine', '123456', 'Amine@gmail.com', 'AmineAchour', 24, 'Homme', 50660838, '2021-03-09', 1, 0, 'http://localhost/PiJava/2nd.png', 0),
(13, 'Amineesprit', '123456789', 'mohamedamine.achour@esprit.tn', 'Am', 23, 'Homme', 50660838, '2021-03-11', 1, 25999, 'http://localhost/PiJava/2nd.png', 0),
(39, 'nouvcompte', '123456', 'nouv@gmail.com', 'amin', 22, 'Homme', 99869986, '2021-04-02', NULL, NULL, 'http://localhost/PiJava/UserIcon.png', 0);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `commentaire_ibfk_1` FOREIGN KEY (`idNews`) REFERENCES `news` (`id`);

--
-- Contraintes pour la table `reclamation`
--
ALTER TABLE `reclamation`
  ADD CONSTRAINT `reclamation_ibfk_1` FOREIGN KEY (`IDUser`) REFERENCES `utilisateur` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
