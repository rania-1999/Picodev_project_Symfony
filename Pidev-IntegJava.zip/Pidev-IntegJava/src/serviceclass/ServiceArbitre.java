/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

import entite.Arbitre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Utils.MaConnexion;

/**
 *
 * @author rania arafa
 */
public class ServiceArbitre {
      Connection cnx;

    public ServiceArbitre() {
        cnx=MaConnexion.getInstance().getConnection();  }
    
    public void AjouterArbitre(Arbitre a) {
        try {
            String requete = "INSERT INTO arbitre (nom,prenom,filiere,image,disponibilite, date_arbitre)"
                    + "VALUES ('"+a.getNom()+"','"+a.getPrenom()+"','"+a.getFiliere()+"','"+a.getImage()+"','"+a.getDisponiblite()+"','"+a.getDate_arbitre()+"')";
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("arbitre ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
     
    }

  
    public List<Arbitre> AfficherArbitre() {
    
      
            List <Arbitre> arbitres =new ArrayList<>();
            
            try {
            String requete = "SELECT * FROM arbitre";
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
                Arbitre a = new Arbitre();
               a.setId(rs.getInt ("id"));
                a.setNom(rs.getString("nom"));
                a.setPrenom(rs.getString("prenom"));
                     a.setFiliere(rs.getString("filiere"));
a.setImage(rs.getString("image"));
a.setDisponiblite(rs.getString("disponibilite"));
a.setDate_arbitre(rs.getDate("date_arbitre"));
                     arbitres.add(a);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            
     
       return arbitres;

    }
         public void supprimerArbitre (Arbitre a)
         {/*
           try {
            String requete = "DELETE FROM arbitre where id=?";
            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, a.getId());
            pst.executeUpdate();
            System.out.println("arbitre supprimé");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
     */    }
}
    //       public void updateArbitre( Arbitre a) {
 
               /*try{
   String req = "UPDATE arbitre SET id=[value-1], nom=[value-2],prenom=[value-3],filiere=[value-4] WHERE 1";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);

       pst.setInt(1,a.getId());
            pst.setString(2,a.getNom());
           
            pst.setString(3,a.getPrenom());
                        pst.setString(4,a.getFiliere());

            pst.executeUpdate();
        }catch(SQLException ex){
            System.out.println("non modifie");
        }

             }*/

   //        }
