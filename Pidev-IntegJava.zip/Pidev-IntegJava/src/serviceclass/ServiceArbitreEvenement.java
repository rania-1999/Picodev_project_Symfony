/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

import entite.Arbitre;
import entite.Evenement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import Service.IArbitreEvenement;
import Utils.MaConnexion;

/**
 *
 * @author rania arafa
 */
public class ServiceArbitreEvenement implements IArbitreEvenement{
    HashMap<Arbitre, Evenement> hashMap = new HashMap<>();

   

    @Override
    public void afficherdesArbitresDansEvenement() {
 
            try {
            String requete = "SELECT `id_evenement`,`nom_evenement`, `nom` FROM `evenement`, `arbitre` WHERE evenement.id_evenement=arbitre.id";
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
                Arbitre a = new Arbitre();
             Evenement e= new Evenement();
                a.setNom(rs.getString("nom"));
                    
                     e.setNom_evenement(rs.getString("id_evenement"));
                  e.setId_evenement(rs.getInt("id_evenement"));
//a.setImage(rs.getString("image"));
                     hashMap.put(a,e);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            
     

    }


    }
    

