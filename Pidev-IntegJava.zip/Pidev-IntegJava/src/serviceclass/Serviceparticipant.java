/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Service.IServiceparticipant;
import Utils.MaConnexion;
import entite.Participant;

/**
 *
 * @author Bechir



import entite.Participant;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Service.IServiceparticipant;
import Utils.MaConnexion;

/**
 *
 * @author Bechir
 */
public class Serviceparticipant implements IServiceparticipant{
    Connection cnx;

    public Serviceparticipant() {
         cnx=MaConnexion.getInstance().getConnection();
    }
    
    
    
    @Override
    public void ajouter_participant(Participant p) {
       
      try {
            String requete = "INSERT INTO participant (nom,prenom)"
                    + "VALUES ('"+p.getNom()+"','"+p.getPrenom()+"')";
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Participant ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        
         
    }

    @Override
    public List<Participant> affichage_participant() {
         
             List <Participant> Participant =new ArrayList<>();
            
            try {
            String requete = "SELECT * FROM participant";
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
               Participant p= new Participant();
               
               
                p.setNom(rs.getString("nom"));
                p.setPrenom(rs.getString("prenom"));
                Participant.add(p);
            }
                } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            return Participant;
            
    }
  

    @Override
    public void supprimerparticipant(Participant p) {
        try {
            String requete = "DELETE FROM participant where id=?";
            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, p.getId());
            pst.executeUpdate();
            System.out.println("Participant supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    @Override
  public void updateparticipant(Participant p) {

                 try {
            String requete = "UPDATE `participant` SET `id`=[value-1],`nom`=[value-2],`prenom`=[value-3] WHERE 1";
            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setString(2, p.getNom());
            pst.setString(3, p.getPrenom());
            pst.setInt(1, p.getId());
            pst.executeUpdate();
                     System.out.println("participant modifié");
} catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }  
    
    
    
    
    
    
    
    
    
    
}

    @Override
    public void ajouter_participantm(Participant p) {
 try {
            String requete = "INSERT INTO participant (nom,prenom)"
                    + "VALUES ('"+p.getNom()+"','"+p.getPrenom()+"')";
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Participant ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
            }

   
}

    
    