/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

/**
 *
 * @author Bechir
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Service.IServicematch;
import Utils.MaConnexion;
import entite.Match;

/**
 *
 * @author Bechir



import entite.Match;
import entite.Participant;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Service.IServicematch;
import Utils.MaConnexion;

/**
 *
 * @author Bechir
 */

public class Servicematch implements IServicematch{
    Connection cnx;

    public Servicematch() {
         cnx=MaConnexion.getInstance().getConnection();
    }
    
    
    String s;
    @Override
    public void ajouter_match(Match m) {
       
      try {
            String requete = "INSERT INTO `match`( `equipeA`, `equipeB`, `date`, `tour`,`image`) "
                    +"VALUES ('"+m.getEquipeA()+"','"+m.getEquipeB()+"','"+m.getDate()+"','"+m.getTour()+"','"+m.getImage()+"')";
            
            
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Match ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        
         
    }

    @Override
    public List<Match> affichage_match() {
         
             List <Match> Match =new ArrayList<>();
            
            try {
            String requete = "SELECT * FROM match";
                   
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
               Match m= new Match();
               
               m.setId_m(rs.getInt("id_m"));
                m.setEquipeA(rs.getString("equipeA"));
                m.setEquipeB(rs.getString("equipeB"));
                 m.setDate(rs.getDate("date"));
                  m.setTour(rs.getString("tour"));
                   m.setImage(rs.getString("image"));
                   // m.setnom(rs.getString("nom"));
                Match.add(m);
            }
                } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            return Match;
            
    }
  

    @Override
    public void supprimer_match(Match m) {
        try {
            String requete = "DELETE FROM match where id_m= ?";
            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, m.getId_m());
            pst.execute();
           
            System.out.println("Match supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
  

    @Override
    public void ajouter_matchp(Match m) {
            
      try {
            String requete = "INSERT INTO `match`( `equipeA`, `equipeB`, `date`) "
                    +"VALUES ('"+m.getEquipeA()+"','"+m.getEquipeB()+"','"+m.getDate()+"')";
            
            
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Match ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        
    }

    @Override
    public void updatematch(Match m) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
        
  


    
    
    
    
    
    
    
    
    
}
