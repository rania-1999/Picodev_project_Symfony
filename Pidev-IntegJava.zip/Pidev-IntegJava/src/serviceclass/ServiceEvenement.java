/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

import entite.Evenement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import Service.IServiceEvenement;
import Utils.MaConnexion;

/**
 *
 * @author rania arafa
 */
public class ServiceEvenement implements IServiceEvenement{
    Connection cnx;

    public ServiceEvenement() {
        cnx=MaConnexion.getInstance().getConnection();  }
    
    @Override
    public void AjouterEvenement(Evenement e) {
        try {
            String requete = "INSERT INTO evenement (nom_evenement,descrip_evenement,date_evenement)"
                    + "VALUES ('"+e.getNom_evenement()+"','"+e.getDescrip_evenement()+"','"+e.getDate_evenement()+"')";
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("evenement ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
     
    }

    @Override
    public List<Evenement> AfficherEvenement() {
    
      
            List <Evenement> evenements =new ArrayList<>();
            
            try {
            String requete = "SELECT * FROM evenement";
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
                Evenement e = new Evenement();
               e.setId_evenement(rs.getInt ("id_evenement"));
                e.setNom_evenement(rs.getString("nom_evenement"));
                e.setDescrip_evenement(rs.getString("descrip_evenement"));
                e.setDate_evenement(rs.getDate("date_evenement"));
                evenements.add(e);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            
     
       return evenements;

    }
    
    @Override
         public void supprimerEvenement (Evenement e)
         {
           try {
            String requete = "DELETE FROM evenement where id_evenement=?";
            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, e.getId_evenement());
            pst.executeUpdate();
            System.out.println("evenement supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    @Override
           public void updateEvenement( Evenement e) {
 try{
   String req = "UPDATE evenement SET id_evenement=[value-1], nom_evenement=[value-2],descrip_evenement=[value-3] WHERE 1";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);

       pst.setInt(1,e.getId_evenement());
            pst.setString(2,e.getNom_evenement());
           
            pst.setString(3,e.getDescrip_evenement());
            pst.executeUpdate();
        }catch(SQLException ex){
            System.out.println("non modifie");
        }

             }

}