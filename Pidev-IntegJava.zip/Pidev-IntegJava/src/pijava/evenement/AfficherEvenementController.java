/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Afficher les evenements pour l uilisateur
package pijava.evenement;
import Utils.MaConnexion;
import com.itextpdf.text.Element;
import entite.Evenement;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import Utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Node;
import pijava.UsersFront.UsersListController;

/**
 * FXML Controller class
 *
 * @author rania arafa
 */
public class AfficherEvenementController implements Initializable {

    
    @FXML
    private VBox v_evenement;
    @FXML
    private TableColumn<Evenement, String> nom_evenement;
    @FXML
    private TableColumn<Evenement, String> description;
    @FXML
    private TableColumn<Evenement, String> date;
    @FXML
    private Button participe;

    /**
     * Initializes the controller class.
     */
        ObservableList<Evenement> listE;
    @FXML
    private TableView<Evenement> table_evenement;
    @FXML
    private Label M;
    @FXML
    private ImageView LogoIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameHOME;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        nom_evenement.setCellValueFactory(new PropertyValueFactory<Evenement, String>("nom_evenement"));
 description.setCellValueFactory(new PropertyValueFactory<Evenement,String>("descrip_evenement"));
 date.setCellValueFactory(new PropertyValueFactory<Evenement,String>("date_evenement"));
 listE=MaConnexion.getDataevenementsU();
 table_evenement.setItems(listE);

    }  



    
    


    @FXML
    private void participer(ActionEvent event) throws IOException {
        
             Parent root = FXMLLoader.load(getClass().getResource("formulaireEvenement.fxml"));
    Stage window= (Stage) participe.getScene().getWindow();
    window.setScene(new Scene(root));
        
    }
   int index=1;

    @FXML
    private void RetourOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Login/Accueil.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AfficherEvenementController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
        
    }
     
    
}
