/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.evenement;

import entite.Evenement;
import entite.Match;
import entite.Participant;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import serviceclass.Serviceparticipant;
import Utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Node;
import pijava.UsersFront.UsersListController;

/**
 * FXML Controller class
 *
 * @author rania arafa
 */
//formulaire pour utilisateur
public class FormulaireEvenementController implements Initializable {

    private Button goMatch;
    private Button goEvenement;
    private Button goArbitre;
    @FXML
    private TextField nomp;
    @FXML
    private TextField prenomp;
    @FXML
    private ComboBox datep;

    /**
     * Initializes the controller class.
     */
            ObservableList<Evenement> listE;
    @FXML
    private Label combo_dateE;
    @FXML
    private ImageView LogoIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameHOME;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
           listE = MaConnexion.getDataDateEvenements();
     datep.setItems(listE);
    }    


    private void GoToMatch(ActionEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("affichage_match.fxml"));
    Stage window= (Stage) goMatch.getScene().getWindow();
    window.setScene(new Scene(root));
    }

    private void GoToEvenement(ActionEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("afficherEvenement.fxml"));
    Stage window= (Stage) goEvenement.getScene().getWindow();
    window.setScene(new Scene(root));
    }


    private void GoToArbitre(ActionEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("afficherArbitre.fxml"));
    Stage window= (Stage) goArbitre.getScene().getWindow();
    window.setScene(new Scene(root));
    }


    @FXML
    private void select_date(ActionEvent event) {
        Evenement e=new Evenement();
    String m=datep.getSelectionModel().getSelectedItem().toString();

combo_dateE.setText("vous etes inscrit dans un evnement "+m);

   
    }

    @FXML
    private void ajouterP(ActionEvent event) {
        
       Serviceparticipant sps=new Serviceparticipant();
       Participant p=new Participant();
       
        
      p.setNom(nomp.getText());
         p.setPrenom(prenomp.getText());
         sps.ajouter_participantm(p);
         
              System.out.println("click");
        Notifications.create().title("félicitation ")
                .text("vous participerez a cet evenement ").darkStyle().position(Pos.TOP_LEFT)
                .showWarning();
            String m=datep.getSelectionModel().getSelectedItem().toString();
 
         try {
            Evenement em=new Evenement();
         Integer id=em.getId_evenement();
         Integer idpp=p.getId();
         //   String requete = "INSERT INTO `gestion` (`idu`, `ide`, `ida`, `idm`, `idp`) VALUES ('13', '"+em.getId_evenement()+"', '1', '1', '16') where nom_evenement='" + m + "' ";
           String requete="Insert into gestion  (`idu`, `ide`, `ida`, `idm`, `idp`) values ('35','46','16','1','25' ) ";
              Statement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
 Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.execute(requete);

  
            System.out.println("evenement ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
         
    }

    @FXML
    private void RetourOnAction(ActionEvent event) {
        
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Login/Accueil.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(UsersListController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }
    
}
