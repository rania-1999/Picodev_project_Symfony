/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.evenement;
//gestion des evenement admin
import com.gembox.spreadsheet.ExcelFile;
import com.gembox.spreadsheet.ExcelWorksheet;
import com.gembox.spreadsheet.SpreadsheetInfo;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import serviceclass.ServiceEvenement;
import entite.Evenement;
import entite.Participant;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.collections.FXCollections.observableList;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import static javafx.scene.control.cell.ProgressBarTableCell.forTableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.VBox;
import javafx.util.converter.IntegerStringConverter;
import javax.swing.JOptionPane;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import static javax.swing.Spring.height;
import static javax.swing.Spring.width;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import static org.apache.poi.hssf.usermodel.HeaderFooter.file;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import static org.shaded.apache.poi.hssf.usermodel.HeaderFooter.file;
import Utils.MaConnexion;
import static javafx.collections.FXCollections.observableList;
import javafx.scene.Node;
import javafx.scene.image.Image;
import pijava.AdminInterface.AdminInterfaceController;

/**
 *
 * @author rania arafa
 */
public class EvenementController implements Initializable {
    
    private Label label;
 
    @FXML
    private TextField tf_nom;
    @FXML
    private TextField tf_description;
    private Label LabelAffiche;
    @FXML
    private TableView<Evenement> table_evenement;
    @FXML
    private TableColumn<Evenement, Integer> col_id_evenement;
    @FXML
    private TableColumn<Evenement, String> col_nom_evenement;
    @FXML
    private TableColumn<Evenement, String> col_descrip_evenement;
    @FXML
    private TextField tf_id;
    @FXML
    private TextField tf_recherche;
    @FXML
    private DatePicker dateE;
    @FXML
    private TableColumn<Evenement, String> col_date_evenement;
    private ImageView imgqr;
    private Button goMatch;
    @FXML
    private ImageView MatchIMG;
    @FXML
    private ImageView NewsIMG;
    private Button goEvenement;
    @FXML
    private ImageView EventIMG;
    @FXML
    private ImageView RecIMG;
    @FXML
    private ImageView TerrainIMG;
    @FXML
    private ImageView CoachIMG;
    private Button goArbitre;
    @FXML
    private ImageView ArbitreIMG;
    @FXML
    private ImageView GymIMG;
    @FXML
    private ImageView UserIMG;
    @FXML
    private Button goQR;
    @FXML
    private ImageView EventIMG1;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameADMIN;
    @FXML
    private Label UsernameADMIN1;
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    ObservableList<Evenement> listE;
        ObservableList<Evenement> DataList;

    int index=-1;

            
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
       
        File UserIconFile = new File("image/UserIcon.png");
        Image UserIcon = new Image(UserIconFile.toURI().toString());
       // ProfilIMG.setImage(UserIcon);
        
        File MatchFile = new File("image/MatchTXT.png");
        Image MatchIcon = new Image(MatchFile.toURI().toString());
        MatchIMG.setImage(MatchIcon);
        
       
        UserIMG.setImage(UserIcon);
        
         File NewsFile = new File("image/NewsTXT.png");
        Image NewsIcon = new Image(NewsFile.toURI().toString());
        NewsIMG.setImage(NewsIcon);
        
         File EventFile = new File("image/EventTXT.png");
        Image EventIcon = new Image(EventFile.toURI().toString());
        EventIMG.setImage(EventIcon);
        
        File RecFile = new File("image/RecTXT.png");
        Image RecIcon = new Image(RecFile.toURI().toString());
        RecIMG.setImage(RecIcon);
        
        File TerrainFile = new File("image/Terrain.png");
        Image TerrainIcon = new Image(TerrainFile.toURI().toString());
        TerrainIMG.setImage(TerrainIcon);
        
        File CoachFile = new File("image/CoachIcon.png");
        Image CoachIcon = new Image(CoachFile.toURI().toString());
        CoachIMG.setImage(CoachIcon);
        
        File ArbitreFile = new File("image/ArbitreIcon.png");
        Image ArbitreIcon = new Image(ArbitreFile.toURI().toString());
        ArbitreIMG.setImage(ArbitreIcon);
        
        File GymFile = new File("image/GymIcon.png");
        Image GymIcon = new Image(GymFile.toURI().toString());
        GymIMG.setImage(GymIcon);
        //
        
      col_id_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,Integer>("id_evenement"));
 col_nom_evenement.setCellValueFactory(new PropertyValueFactory<Evenement, String>("nom_evenement"));
 col_descrip_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("descrip_evenement"));
 col_date_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("date_evenement"));

 listE=MaConnexion.getDataevenements();
   table_evenement.setItems(listE);
   table_evenement.setEditable(true);
       
    }    

    @FXML
    private void AjouterEvenement(ActionEvent event) {
       if(valideFields()){ ServiceEvenement sp=new ServiceEvenement();
        Evenement e =new Evenement();
        e.setNom_evenement(tf_nom.getText());
         e.setDescrip_evenement(tf_description.getText());
         e.setDate_evenement(Date.valueOf(dateE.getValue()));
        sp.AjouterEvenement(e);
       updateEvenement();
    }}

   
    

    @FXML
    private void supprimerEvenement(ActionEvent event) 
    { 
        try{  String req = "DELETE FROM evenement WHERE id_evenement=?";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
          pst.setString(1, tf_id.getText());

pst.execute();
        ObservableList<Evenement> evenements, SingleEvenements;
       evenements=table_evenement.getItems();
       SingleEvenements=table_evenement.getSelectionModel().getSelectedItems();
  SingleEvenements.forEach(evenements::remove);
   JOptionPane.showMessageDialog(null, "evenement supprime");}
    catch (SQLException e) {JOptionPane.showMessageDialog(null, e);}
     }
    private void updateEvenement  ( ) {
         col_id_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,Integer>("id_evenement"));
 col_nom_evenement.setCellValueFactory(new PropertyValueFactory<Evenement, String>("nom_evenement"));
 col_descrip_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("descrip_evenement"));
  col_date_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("date_evenement"));

   listE=MaConnexion.getDataevenements();
   table_evenement.setItems(listE);
   table_evenement.setEditable(true);
       
 
   
    }

    @FXML
    private void trouverEvenement(ActionEvent event)throws IOException, ParseException {
      col_id_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,Integer>("id_evenement"));
 col_nom_evenement.setCellValueFactory(new PropertyValueFactory<Evenement, String>("nom_evenement"));
 col_descrip_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("descrip_evenement"));
  col_date_evenement.setCellValueFactory(new PropertyValueFactory<Evenement,String>("date_evenement"));
   DataList=MaConnexion.getDataevenements();
table_evenement.setItems(DataList);
        FilteredList<Evenement> filteredDataEvenements=new FilteredList<>(DataList,b->true);
         tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredDataEvenements.setPredicate(Evenement -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
    
    if (Evenement.getNom_evenement().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches nom
    } else if (Evenement.getDescrip_evenement().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches description
    }else if (Evenement.getDescrip_evenement().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
    }   else  
          return false; // Does not match.
   });
  });  
  SortedList<Evenement> sortedData = new SortedList<>(filteredDataEvenements);  
  sortedData.comparatorProperty().bind(table_evenement.comparatorProperty());  
  table_evenement.setItems(sortedData);      
    }
  
    @FXML
    private void editerEvenement(ActionEvent event)  {
        if(valideFields()) {  try {
           String v2=tf_nom.getText();
           String v3=tf_description.getText();
          
     String req = "update evenement set nom_evenement= '"+v2+"',descrip_evenement= '"+
                    v3+"' ";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
pst.executeUpdate();
               updateEvenement();
            JOptionPane.showMessageDialog(null, "update");
           } catch (SQLException e) {JOptionPane.showMessageDialog(null, e);
        }
    }
        

    }
    @FXML
    private void Selection(javafx.scene.input.MouseEvent event) {
        
        index=table_evenement.getSelectionModel().getSelectedIndex();
        if (index<=-1) {return;
            
        }
       tf_id.setText(col_id_evenement.getCellData(index).toString());
            tf_nom.setText(col_nom_evenement.getCellData(index));
        tf_description.setText(col_descrip_evenement.getCellData(index));
        dateE.setPromptText(col_date_evenement.getCellData(index));
      
        
    }
    
     private boolean valideFields()
    {if(tf_nom.getText().isEmpty()|tf_description.getText().isEmpty() ) 
    {Alert alert= new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("valider");
        alert.setHeaderText(null);
        alert.setContentText("entrer un text!!");
        alert.showAndWait();
    return false;
    }return true ; }

  
 //FileOutputStream ff;

@FXML
    private void AjouterMap(ActionEvent event) throws SQLException, IOException{
    try {
         String requete = "SELECT  `nom_evenement`, `descrip_evenement`, `date_evenement` FROM `evenement`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
        SpreadsheetInfo.setLicense("FREE-LIMITED-KEY");

ExcelFile workbook = new ExcelFile();
                    System.out.println("oui");

ExcelWorksheet sheet = workbook.addWorksheet("evenement");
         sheet.getCell(0,0).setValue("NOM");
       sheet.getCell(0, 1).setValue("DESC");

       sheet.getCell(0, 2).setValue("DATE:");
int idx = 1;
    while (rs.next()) {
sheet.getCell(idx, 0).setValue(rs.getString("nom_evenement"));
       sheet.getCell(idx, 1).setValue(rs.getString("descrip_evenement"));
       sheet.getCell(idx, 2).setValue(rs.getString("date_evenement"));
System.out.println("non");
idx++;
        workbook.save("evenement.xlsx");

    
    } }catch (SQLException e) {System.out.println("non");
    }
           

    




    }

   

    


    @FXML
    private void GoToQR(ActionEvent event) throws IOException {
          Parent root = FXMLLoader.load(getClass().getResource("/pijava/gestionQR.fxml"));
    Stage window= (Stage) goQR.getScene().getWindow();
    window.setScene(new Scene(root));
    }

     @FXML
    private void MatchControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/match/match.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void EventControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/evenement/evenement.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void ArbitreControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/arbitre/Arbitre.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }
    
    @FXML
    private void UserControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminUser/BackUserList.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void RecControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminReclamation/BackReclamation.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void DashboardOnAction(ActionEvent event) {
            // direction interface admin 
         Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader ();
        loader.setLocation(getClass().getResource("/pijava/AdminInterface/AdminInterface.fxml"));
        try {
        loader.load();


        } catch (IOException ex) {
        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("failed to load");
        System.out.println(ex);
        }
        Parent parent = loader.getRoot();
        stage.setScene(new Scene(parent));
        stage.show();
    }

    @FXML
    private void CoachControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/CoachBack/BackMenuCoach.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void NewsControlOnAction(ActionEvent event) {
        Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/NewsCom/FXMLNews0.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void TerrControlOnAction(ActionEvent event) {
          Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Terrain/Terrain.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }



}
  
  
   
    

