/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//GERER LES ARBITRES ADMIN
package pijava.arbitre;

import serviceclass.ServiceArbitre;
import serviceclass.ServiceEvenement;

import entite.Arbitre;
import entite.Evenement;
import entite.Participant;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Blob;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;

import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.Spring.height;
import static javax.swing.Spring.width;
import javax.swing.filechooser.FileNameExtensionFilter;
import static jdk.nashorn.internal.codegen.OptimisticTypesPersistence.store;
import Utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Node;
import pijava.AdminInterface.AdminInterfaceController;
import pijava.match.MatchController;


/**
 * FXML Controller class
 *
 * @author rania arafa
 */
public class ArbitreController implements Initializable {

    @FXML
    private TextField tf_nom;
    @FXML
    private TextField tf_prenom;
    @FXML
    private TextField tf_filiere;
    @FXML
    private TextField tf_id;
    @FXML
    private TextField tf_recherche;
    @FXML
    private TableView<Arbitre> table_arbitre;
    @FXML
    private TableColumn<Arbitre, Integer> col_id_arbitre;
    @FXML
    private TableColumn<Arbitre, String> col_id_nom;
    @FXML
    private TableColumn<Arbitre, String> col_id_prenom;
    @FXML
    private TableColumn<Arbitre, String> col_id_filiere;
    /**
     * Initializes the controller class.
     */
    String s;
  String disp;
    ObservableList<Arbitre> listA;
    ObservableList<Arbitre> DataListA;
    private FileChooser fileChooser;

    private FileInputStream fis;
    int index = -1;
    private ImageView labimage;
    @FXML
    private TextArea txt_filename;
    @FXML
    private TableColumn<Arbitre, String> col_id_img;


  
    @FXML
    private TableColumn<Arbitre, String> col_id_date_arbitre;
    @FXML
    private DatePicker date_A;
    private Button aff;
    @FXML
    private ImageView MatchIMG;
    @FXML
    private ImageView NewsIMG;
    
    @FXML
    private ImageView EventIMG;
    @FXML
    private ImageView RecIMG;
    @FXML
    private ImageView TerrainIMG;
    @FXML
    private ImageView CoachIMG;
    @FXML
    private ImageView ArbitreIMG;
    @FXML
    private ImageView GymIMG;
    @FXML
    private ImageView UserIMG;
    @FXML
    private ImageView laff;
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
         File UserIconFile = new File("image/UserIcon.png");
        javafx.scene.image.Image UserIcon = new javafx.scene.image.Image(UserIconFile.toURI().toString());
       // ProfilIMG.setImage(UserIcon);
        
        File MatchFile = new File("image/MatchTXT.png");
        javafx.scene.image.Image MatchIcon = new javafx.scene.image.Image(MatchFile.toURI().toString());
        MatchIMG.setImage(MatchIcon);
        
       
        UserIMG.setImage(UserIcon);
        
         File NewsFile = new File("image/NewsTXT.png");
        javafx.scene.image.Image NewsIcon = new javafx.scene.image.Image(NewsFile.toURI().toString());
        NewsIMG.setImage(NewsIcon);
        
         File EventFile = new File("image/EventTXT.png");
        javafx.scene.image.Image EventIcon = new javafx.scene.image.Image(EventFile.toURI().toString());
        EventIMG.setImage(EventIcon);
        
        File RecFile = new File("image/RecTXT.png");
        javafx.scene.image.Image RecIcon = new javafx.scene.image.Image(RecFile.toURI().toString());
        RecIMG.setImage(RecIcon);
        
        File TerrainFile = new File("image/Terrain.png");
        javafx.scene.image.Image TerrainIcon = new javafx.scene.image.Image(TerrainFile.toURI().toString());
        TerrainIMG.setImage(TerrainIcon);
        
        File CoachFile = new File("image/CoachIcon.png");
        javafx.scene.image.Image CoachIcon = new javafx.scene.image.Image(CoachFile.toURI().toString());
        CoachIMG.setImage(CoachIcon);
        
        File ArbitreFile = new File("image/ArbitreIcon.png");
        javafx.scene.image.Image ArbitreIcon = new javafx.scene.image.Image(ArbitreFile.toURI().toString());
        ArbitreIMG.setImage(ArbitreIcon);
        
        File GymFile = new File("image/GymIcon.png");
        javafx.scene.image.Image GymIcon = new javafx.scene.image.Image(GymFile.toURI().toString());
        GymIMG.setImage(GymIcon);
        
        // TODO
        col_id_arbitre.setCellValueFactory(new PropertyValueFactory<Arbitre, Integer>("id"));
        col_id_nom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("nom"));
        col_id_prenom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("prenom"));
        col_id_filiere.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("filiere"));
        col_id_img.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("image"));
            col_id_date_arbitre.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("date_arbitre"));

        listA = MaConnexion.getDataarbitres();
        table_arbitre.setItems(listA);
        table_arbitre.setEditable(true);

    }

    @FXML
    private void trouverArbitre(ActionEvent event) {
        col_id_arbitre.setCellValueFactory(new PropertyValueFactory<Arbitre, Integer>("id"));
        col_id_nom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("nom"));
        col_id_prenom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("prenom"));
        col_id_filiere.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("filiere"));

        DataListA = MaConnexion.getDataarbitres();
        table_arbitre.setItems(DataListA);
        FilteredList<Arbitre> filteredDataArbitres = new FilteredList<>(DataListA, b -> true);
        tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredDataArbitres.setPredicate(Arbitre -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (Arbitre.getNom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches nom
                } else if (Arbitre.getPrenom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches description
                } else if (Arbitre.getFiliere().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true; // Filter matches int
                } else {
                    return false; // Does not match.
                }
            });
        });
        SortedList<Arbitre> sortedData = new SortedList<>(filteredDataArbitres);
        sortedData.comparatorProperty().bind(table_arbitre.comparatorProperty());
        table_arbitre.setItems(sortedData);

    }

    @FXML
    private void supprimerArbitre(ActionEvent event) {
        try {
            String req = "DELETE FROM arbitre WHERE id=?";
            PreparedStatement pst = MaConnexion.getInstance().getConnection().prepareStatement(req);
            pst.setString(1, tf_id.getText());

            ObservableList<Arbitre> arbitres, SingleEvenements;
            arbitres = table_arbitre.getItems();
            SingleEvenements = table_arbitre.getSelectionModel().getSelectedItems();
            SingleEvenements.forEach(arbitres::remove);
            JOptionPane.showMessageDialog(null, "arbitre supprime");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    @FXML
    private void ajouterArbitre(ActionEvent event) {
        String path = txt_filename.getText();
        if (valideFields()) {
            ServiceArbitre sp = new ServiceArbitre();
            Arbitre a = new Arbitre();
            a.setNom(tf_nom.getText());
            a.setPrenom(tf_prenom.getText());
          a.setFiliere(tf_filiere.getText());
            a.setImage(txt_filename.getText());
            
      
    a.setDate_arbitre(java.sql.Date.valueOf(date_A.getValue()));
    sp.AjouterArbitre(a);
            updateArbitre();
   }

    }

    @FXML
    private void editerAbitre(ActionEvent event) {
    if(valideFields())   { try {
            String v1 = tf_id.getText();
            String v2 = tf_nom.getText();
            String v3 = tf_prenom.getText();
            String v4 = tf_filiere.getText();

            String req = "update arbitre set id= '" + v1 + "',nom= '" + v2 + "',prenom= '"
                    + v3 + "',filiere= '"
                    + v4 + "' where id='" + v1 + "' ";
            PreparedStatement pst = MaConnexion.getInstance().getConnection().prepareStatement(req);
            pst.executeUpdate();
            updateArbitre();
            JOptionPane.showMessageDialog(null, "update");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }}

    private void updateArbitre() {

        col_id_arbitre.setCellValueFactory(new PropertyValueFactory<Arbitre, Integer>("id"));
        col_id_nom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("nom"));
        col_id_prenom.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("prenom"));
        col_id_filiere.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("filiere"));
        col_id_date_arbitre.setCellValueFactory(new PropertyValueFactory<Arbitre, String>("date_arbitre"));
        listA = MaConnexion.getDataarbitres();
        table_arbitre.setItems(listA);
        table_arbitre.setEditable(true);

    }
    private File file;

    @FXML
    private void selected(MouseEvent event) throws URISyntaxException, FileNotFoundException {

        FileChooser fe = new FileChooser();
        index = table_arbitre.getSelectionModel().getSelectedIndex();
        if (index <= -1) {
            return;

        }
        tf_id.setText(col_id_arbitre.getCellData(index).toString());
        tf_nom.setText(col_id_nom.getCellData(index));
        tf_prenom.setText(col_id_prenom.getCellData(index));
        tf_filiere.setText(col_id_filiere.getCellData(index));
        txt_filename.setText(col_id_img.getCellData(index));
        String affi = txt_filename.getText();
                File file = new File(affi);
                
            laff.setImage(new javafx.scene.image.Image(file.toURI().toString()));

//afficher();
    }
    private void afficher()
    {
    try{String requete = "select image from arbitre";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
           String image=rs.getString("image");
            labimage.setImage(new javafx.scene.image.Image(file.toURI().toString()));
       }
   
   }catch (SQLException e){ System.out.println("non image");}
       
     
    
    
    
    }

    /*  if (path!=null)
      {
      
     labimage.setImage(new javafx.scene.image.Image(path.toURI().toString()));
      }else {
          System.out.println("a file is invalide");
      }*/
    private boolean valideFields() {
        if (tf_nom.getText().isEmpty() || tf_prenom.getText().isEmpty() || tf_filiere.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("WARNING");
            alert.setHeaderText(null);
            alert.setContentText("entrer un text!!");
            alert.showAndWait();
            return false;
        }
        return true;
    }

    String filename = null;
    String p;

    @FXML
    private void parcourir(ActionEvent event) throws FileNotFoundException {

        // Arbitre a=new  Arbitre();
        FileChooser fe = new FileChooser();

        fe.setTitle("image chooser");
        fe.setInitialDirectory(new File(System.getProperty("user.home")));
        fe.getExtensionFilters().clear();
        fe.getExtensionFilters().add(new FileChooser.ExtensionFilter("image file", "*.jpeg", "*.png", "*.gif"));
        File file = fe.showOpenDialog(null);
        txt_filename.appendText(file.getAbsolutePath());
        if (file != null) {
            laff.setImage(new javafx.scene.image.Image(file.toURI().toString()));
        } else {
            System.out.println("a file is invalide");
        }

    }

  



   

    private void AfficherArbitre(ActionEvent event) throws IOException {
  
     Parent root = FXMLLoader.load(getClass().getResource("afficherArbitre.fxml"));
    Stage window= (Stage) aff.getScene().getWindow();
    window.setScene(new Scene(root));
    }


   
   

   
    @FXML
    private void UserControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminUser/BackUserList.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void RecControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminReclamation/BackReclamation.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void DashboardOnAction(ActionEvent event) {
            // direction interface admin 
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader ();
        loader.setLocation(getClass().getResource("/pijava/AdminInterface/AdminInterface.fxml"));
        try {
        loader.load();


        } catch (IOException ex) {
        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("failed to load");
        System.out.println(ex);
        }
        Parent parent = loader.getRoot();
        stage.setScene(new Scene(parent));
        stage.show();
    }

    @FXML
    private void CoachControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/CoachBack/BackMenuCoach.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void NewsControlOnAction(ActionEvent event) {
        Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/NewsCom/FXMLNews0.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(MatchController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void MatchControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/match/match.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void EventControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/evenement/evenement.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void ArbitreControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/arbitre/Arbitre.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void TerrControlOnAction(ActionEvent event) {
          Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Terrain/Terrain.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
        
    }

    

    

  
    

}
