/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageConfig;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.QRCode;
import com.sun.javafx.iio.ImageStorage.ImageType;
import entite.Arbitre;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.System.out;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import Utils.MaConnexion;

/**
 * FXML Controller class
 *
 * @author rania arafa
 */
public class GestionQRController implements Initializable {

    @FXML
    private ImageView qrp;
    private TextField imgp;
    @FXML
    private Label l;
    @FXML
    private Label nomev;
    @FXML
    private Label nomp;
    @FXML
    private Button goMatch;
    @FXML
    private ImageView MatchIMG;
    @FXML
    private ImageView NewsIMG;
    @FXML
    private Button goEvenement;
    @FXML
    private ImageView EventIMG;
    @FXML
    private ImageView RecIMG;
    @FXML
    private ImageView TerrainIMG;
    @FXML
    private ImageView CoachIMG;
    @FXML
    private Button goArbitre;
    @FXML
    private ImageView ArbitreIMG;
    @FXML
    private ImageView GymIMG;
    @FXML
    private ImageView UserIMG;
    @FXML
    private ImageView EventIMG1;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       
}
//To change body of generated methods, choose Tools | Templates.

    @FXML
    private void read(ActionEvent event) {
          
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        String myWeb = "http://java-buddy.blogspot.com/";
        int width = 300;
        int height = 300;
        String fileType = "png";
        
        BufferedImage bufferedImage = null;
        try {
            BitMatrix byteMatrix = qrCodeWriter.encode(myWeb, BarcodeFormat.QR_CODE, width, height);
            bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            bufferedImage.createGraphics();
            
            Graphics2D graphics = (Graphics2D) bufferedImage.getGraphics();
            graphics.setColor(Color.WHITE);
            graphics.fillRect(0, 0, width, height);
            graphics.setColor(Color.BLACK);
            
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    if (byteMatrix.get(i, j)) {
                        graphics.fillRect(i, j, 1, 1);
                    }
                }
            }
            
            System.out.println("Success...");
            
        } catch (WriterException ex) {

        }
        
        ImageView qrView = new ImageView();
        qrView.setImage(SwingFXUtils.toFXImage(bufferedImage, null));
        try{String requete = "select qrcodeS from qrcode  where idQ=18";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
String s=rs.getString("qrcodeS");
l.setText("qrcode:"+s);
           System.out.println(s);
       }} catch(Exception e){}
     try{String requete = "select nom , nom_evenement from participant , evenement where idQ=18";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
String nec=rs.getString("nom_evenement");
String nom=rs.getString("nom");
nomp.setText("nom participant :"+nom);
        nomev.setText("nom evenement: "+nec);
           System.out.println(nec);
       }} catch(Exception e){}
        StackPane root = new StackPane();
        root.getChildren().add(qrView);

        Scene scene = new Scene(root, 350, 350);
 
           
Stage s=new Stage();
s.setScene(scene);  
s.show();
        
    }

    @FXML
    private void DashboardOnAction(ActionEvent event) {
    }

    @FXML
    private void GoToMatch(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("match.fxml"));
    Stage window= (Stage) goMatch.getScene().getWindow();
    window.setScene(new Scene(root));
    }

    @FXML
    private void GoToEvenement(ActionEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("evenement.fxml"));
    Stage window= (Stage) goEvenement.getScene().getWindow();
    window.setScene(new Scene(root));

    }

    @FXML
    private void RecControlOnAction(ActionEvent event) {
    }

    @FXML
    private void CoachControlOnAction(ActionEvent event) {
    }

    @FXML
    private void GoToArbitre(ActionEvent event) throws IOException { Parent root = FXMLLoader.load(getClass().getResource("Arbitre.fxml"));
    Stage window= (Stage) goArbitre.getScene().getWindow();
    window.setScene(new Scene(root));

    }

    @FXML
    private void UserControlOnAction(ActionEvent event) {
    }
    }
        
  
     
