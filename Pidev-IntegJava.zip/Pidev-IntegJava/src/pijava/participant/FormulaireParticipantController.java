/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_version1;

import entite.Participant;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import serviceclass.Serviceparticipant;

/**
 * FXML Controller class
 *
 * @author rania arafa
 */
public class FormulaireParticipantController implements Initializable {

    private Button goMatch;
    private Button goEvenement;
    @FXML
    private TextField nomp;
    @FXML
    private TextField prenomp;
    @FXML
    private ImageView LogoIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameHOME;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    


    @FXML
    private void ajouterP(ActionEvent event) {
        
       Serviceparticipant sps=new Serviceparticipant();
       Participant p=new Participant();
       
        
      p.setNom(nomp.getText());
         p.setPrenom(prenomp.getText());
         sps.ajouter_participantm(p);
          Notifications.create().title("félicitation ")
                .text("vous participerez a ce match ").darkStyle().position(Pos.TOP_LEFT)
                .showWarning();
    }

    @FXML
    private void RetourOnAction(ActionEvent event) {
        
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Login/Accueil.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(FormulaireParticipantController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }
    
}
