/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.participant;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import static com.itextpdf.text.pdf.BidiOrder.PDF;
import com.itextpdf.text.pdf.PdfDocument;
import static com.itextpdf.text.pdf.PdfName.PDF;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javax.print.*;





import entite.Participant;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;




import serviceclass.Serviceparticipant;

import  java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import Utils.MaConnexion;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Cell;
import static javafx.scene.control.cell.ProgressBarTableCell.forTableColumn;
import javafx.scene.control.cell.TextFieldTableCell;
import javax.management.remote.JMXConnectorFactory;
import jdk.nashorn.internal.runtime.Debug;
import static jdk.nashorn.internal.runtime.Debug.id;
import static org.omg.CORBA.AnySeqHelper.id;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import static javax.print.DocFlavor.BYTE_ARRAY.PDF;
import static javax.print.DocFlavor.INPUT_STREAM.PDF;
import static javax.print.DocFlavor.URL.PDF;
import javax.swing.JOptionPane;
import pijava.AdminInterface.AdminInterfaceController;
import pijava.match.MatchController;





/**
 *
 * @author Bechir
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button button;
    @FXML
    private TextField tf_nom;
   
    private Label label_affiche;
    @FXML
    private TextField tf_prenom;
    @FXML
    private TableView<Participant> table_participant;
    @FXML
    private TableColumn<Participant, Integer> af_id;
    @FXML
    private TableColumn<Participant, String> af_nom;
    @FXML
    private TableColumn<Participant, String> af_prenom;
    @FXML
    private TextField tf_id;
    @FXML
    private TextField tf_recherche;
    private Button goMatch;
    @FXML
    private ImageView MatchIMG;
    @FXML
    private ImageView NewsIMG;
    private Button goEvenement;
    @FXML
    private ImageView EventIMG;
    @FXML
    private ImageView RecIMG;
    @FXML
    private ImageView TerrainIMG;
    @FXML
    private ImageView CoachIMG;
    @FXML
    private ImageView ArbitreIMG;
    @FXML
    private ImageView GymIMG;
    @FXML
    private ImageView UserIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameADMIN;
    @FXML
    private ImageView EventIMG1;
    @FXML
    private Label UsernameADMIN11;
    
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
      ObservableList<Participant> listP;
       ObservableList<Participant> DataList;
    int index=-1;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));
   listP=MaConnexion.getDataParticipant();
  table_participant.setItems(listP);
     
    }    
    @FXML
    private void ajouter_participant(ActionEvent event) {
        if(valide()){
       Serviceparticipant sp=new Serviceparticipant();
       Participant p=new Participant();
      p.setNom(tf_nom.getText());
         p.setPrenom(tf_prenom.getText());
        sp.ajouter_participant(p);
        updateProduct();
       
        
    }}

    private void affichage_participant(ActionEvent event) {
        
        Serviceparticipant sp=new Serviceparticipant();
        
          label_affiche.setText(sp.affichage_participant().toString());
          
       
}

    @FXML
    private void supprimer_btn(ActionEvent event) {
        
        
        try{  String req = "DELETE FROM `participant` WHERE id=?";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
            pst.setString(1, tf_id.getText());

pst.execute();
        
        ObservableList<Participant> evenements, SingleEvenements;
       evenements=table_participant.getItems();
       SingleEvenements=table_participant.getSelectionModel().getSelectedItems();
  SingleEvenements.forEach(evenements::remove);
        }
         catch (SQLException e) {JOptionPane.showMessageDialog(null, e);}
        
    }
    


    @FXML
    private void update_btn(javafx.scene.input.MouseEvent event) {
    }


    @FXML
    private void Select(javafx.scene.input.MouseEvent event) {
  
        
        index =table_participant.getSelectionModel().getSelectedIndex();
        if (index<=-1)
            return;
    
    tf_id.setText(af_id.getCellData(index).toString());
     tf_nom.setText(af_nom.getCellData(index).toString());
       tf_prenom.setText(af_prenom.getCellData(index).toString());
       
         

        
        
    }
    private void updateProduct(){
         af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));
   listP=MaConnexion.getDataParticipant();
  table_participant.setItems(listP);
     
    }
    
    
    
    
    
    @FXML
    public void Edit() {
        try{
            String v1=tf_id.getText();
            String v2=tf_nom.getText();
            String v3=  tf_prenom.getText();
            
        
         String req = " update  participant set id= '"+v1+"',nom= '"+v2+"',prenom= '"+
                    v3+"' where id='"+v1+"' ";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
pst.executeUpdate();
updateProduct();
            JOptionPane.showMessageDialog(null, "update");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
            
        }
        
        
    }

    @FXML
    private void filtrer(ActionEvent event) {
        
        
   af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));     
   DataList=MaConnexion.getDataParticipant();
 table_participant.setItems(DataList);
        FilteredList<Participant> filteredDataparticipant=new FilteredList<>(DataList,b->true);
         tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredDataparticipant.setPredicate(Participant -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
   
    if (Participant.getNom().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches nom
  
    }else if (Participant.getPrenom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
    }   else  
          return false; // Does not match.
   });
  });  
  SortedList<Participant> sortedData = new SortedList<>(filteredDataparticipant);  
  sortedData.comparatorProperty().bind(table_participant.comparatorProperty());  
  table_participant.setItems(sortedData); 


        
        
        
        
        
        
    }
       
    
   private boolean valide()
    {if(tf_nom.getText().isEmpty()|tf_prenom.getText().isEmpty())
    {Alert alert= new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ajout participant");
        alert.setHeaderText(null);
        alert.setContentText("champ vide!!");
        alert.showAndWait();
    return false;
    }return true ; }

  
   
    
    
            
            
           
            
       
         
         
         
         
         
      private FileChooser fc=new FileChooser();

  

    @FXML
    private void save(ActionEvent event) throws Exception {
         
      
         
              try {
            String requete = "SELECT  * FROM `participant` ";
            Statement st = MaConnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
             
            
       Document document = new Document(PageSize.A4, 50, 50, 50, 50);       

       
             
             
             
            
            File file = new File("tesssst.pdf");
            FileOutputStream fileout = new FileOutputStream(file);            
            PdfWriter.getInstance(document, fileout);
            document.addAuthor("Me");
            document.addTitle("My iText Test");
              document.open();
              
            Chunk chunk = new Chunk("iText Test");
                
          
          
String test = "și";

 
  Paragraph paragraph = new Paragraph();
                paragraph.add(test + " Liste Participant");
             
      

                 
          paragraph.setAlignment(Element.ALIGN_CENTER);
            document.add(paragraph);
                
                
                
            
             PdfPTable my_report_table = new PdfPTable(3);
                //create a cell object
                PdfPCell table_cell;
              
                
            
                //Participant p=new Participant();
            while(rs.next()){
                 
                 String id =rs.getString("id");
                                table_cell=new PdfPCell(new Phrase(id));
                                my_report_table.addCell(table_cell);
                                          String nom =rs.getString("nom");

                                table_cell=new PdfPCell(new Phrase(nom));
                                my_report_table.addCell(table_cell);
                                                 String prenom =rs.getString("prenom");

                                table_cell=new PdfPCell(new Phrase(prenom));
                                             

                                my_report_table.addCell(table_cell);
                                System.out.println("ok");
      
     
     }
                                  
            document.add(my_report_table); 
                                document.close();
  rs.close();
  st.close();
            
     
 }catch(SQLException ex){
     ex.printStackTrace();
 }
              
    }          

    @FXML
    private void UserControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminUser/BackUserList.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void RecControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminReclamation/BackReclamation.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void DashboardOnAction(ActionEvent event) {
            // direction interface admin 
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader ();
        loader.setLocation(getClass().getResource("/pijava/AdminInterface/AdminInterface.fxml"));
        try {
        loader.load();


        } catch (IOException ex) {
        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("failed to load");
        System.out.println(ex);
        }
        Parent parent = loader.getRoot();
        stage.setScene(new Scene(parent));
        stage.show();
    }

    @FXML
    private void CoachControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/CoachBack/BackMenuCoach.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void NewsControlOnAction(ActionEvent event) {
        Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/NewsCom/FXMLNews0.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(MatchController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void MatchControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/match/match.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void EventControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/evenement/evenement.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void ArbitreControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/arbitre/Arbitre.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void TerrControlOnAction(ActionEvent event) {
          Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Terrain/Terrain.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
        
    }

    
   
}
    
    
     
 
                

