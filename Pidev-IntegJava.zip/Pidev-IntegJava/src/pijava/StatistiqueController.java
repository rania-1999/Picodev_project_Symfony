/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava;

import entite.Arbitre;
import entite.Match;
import entite.Participant;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import static javafx.scene.input.KeyCode.D;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

/**
 * FXML Controller class
 *
 * @author Bechir
 */

public class StatistiqueController implements Initializable {

    @FXML
    private BarChart<String, Integer> barchart;
    @FXML
    private CategoryAxis xAxis;
 private ObservableList<String> monthNames = FXCollections.observableArrayList();
    @FXML
    private Button showbutton;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        String[] months = DateFormatSymbols.getInstance(Locale.ENGLISH).getMonths();
        // Convert it to a list and add it to our ObservableList of months.
        monthNames.addAll(Arrays.asList(months));
        
        // Assign the month names as categories for the horizontal axis.
        xAxis.setCategories(monthNames);
        
        
        
        
        
        // TODO
    }  
    
    
    ObservableList<Match> listM;
       ObservableList<Match> DataList;
        ObservableList<Arbitre> listArbitre;
    
      public void setPersonData(List<Match> match) {
    	// Count the number of people having their birthday in a specific month.
        int[] monthCounter = new int[12];
        for (Match m : match) {
            int month = m.getDate().getMonth() - 1;
            monthCounter[month]++;
        }

        XYChart.Series<String, Integer> series = new XYChart.Series<>();
        
        // Create a XYChart.Data object for each month. Add it to the series.
        for (int i = 0; i < monthCounter.length; i++) {
        	series.getData().add(new XYChart.Data<>(monthNames.get(i), monthCounter[i]));
        }
        
        barchart.getData().add(series);
    }

    private void showbutton() {
        
        
        try {
        // Load the fxml file and create a new stage for the popup.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(StatistiqueController.class.getResource(""));
        AnchorPane page = (AnchorPane) loader.load();
        Stage dialogStage = new Stage();
        dialogStage.setTitle("");
        dialogStage.initModality(Modality.WINDOW_MODAL);
       // Stage primaryStage=new Stage();
        //dialogStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);
         Group root = new Group(barchart);
        
      //Creating a scene object
      Scene scene1 = new Scene(root, 600, 400);

      //Setting title to the Stage
     // Stage.setTitle("Bar Chart");
        
      //Adding scene to the stage
      //stage.setScene(scene);

        // Set the persons into the controller.
        StatistiqueController controller = loader.getController();
        controller.setPersonData(DataList);

        dialogStage.show();

    } catch (IOException e) {
        e.printStackTrace();
    }
    }

    @FXML
    private void show() {
  showbutton();
}
    
        
        
        
        
            
    }

    

