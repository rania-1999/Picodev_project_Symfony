/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.match;
//gestion match pour admin


import entite.Arbitre;
import entite.Match;
import entite.Participant;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javax.swing.JOptionPane;
import serviceclass.Servicematch;
import Utils.MaConnexion;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.text.Document;
import org.controlsfx.control.Notifications;
import pijava.AdminInterface.AdminInterfaceController;
import serviceclass.Serviceparticipant;


/**
 * FXML Controller class
 *
 * @author Bechir
 */
public class MatchController implements Initializable {

    @FXML
    private TextField tf_equipe1;
    @FXML
    private TextField tf_equipe2;
   
    @FXML
    private TextField tf_id;
    @FXML
    private TableView<Match> table_match;
    @FXML
    private TableColumn<Match, Integer> af_id;
    @FXML
    private TableColumn<Match, String> af_equipe1;
    @FXML
    private TableColumn<Match, String> af_equipe2;
    @FXML
    private TableColumn<Match, String> af_date;
    @FXML
    private TableColumn<Match, String> af_tour;
    @FXML
    private TextField tf_recherche;

    /**
     * Initializes the controller class.
     */
   
    @FXML
    private Button button;
    @FXML
    private Button parcourir;
    
    @FXML
    private TableColumn <Match, String> af_text;
    @FXML
    private DatePicker tf_date2;
    private TextField tf_date;
    @FXML
    private DatePicker tf_calendrier;
    @FXML
    private ComboBox combobox;
    private Button statistique;
    private Button goMatch;
    @FXML
    private ImageView MatchIMG;
    @FXML
    private ImageView NewsIMG;
    private Button goEvenement;
    @FXML
    private ImageView EventIMG;
    @FXML
    private ImageView RecIMG;
    @FXML
    private ImageView TerrainIMG;
    @FXML
    private ImageView CoachIMG;
    private Button goArbitre;
    @FXML
    private ImageView ArbitreIMG;
    @FXML
    private ImageView GymIMG;
    @FXML
    private ImageView UserIMG;
    @FXML
    private ImageView lmatch;
    @FXML
    private Label UsernameADMIN1;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameADMIN;
    @FXML
    private Button goStat;
    @FXML
    private ImageView EventIMG16;
    @FXML
    private Button goParticipant;
    @FXML
    private ImageView EventIMG161;
    
        
     ObservableList<Match> listM;
       ObservableList<Match> DataList;
        ObservableList<Arbitre> listArbitre;
       
    int index=-1;
    String s;
    @FXML
    private TextField text_tour;
    @FXML
    private TextField aff;

    @Override
    
   
    public void initialize(URL url, ResourceBundle rb) {
        
         
        File UserIconFile = new File("image/UserIcon.png");
        Image UserIcon = new Image(UserIconFile.toURI().toString());
       // ProfilIMG.setImage(UserIcon);
        
        File MatchFile = new File("image/MatchTXT.png");
        Image MatchIcon = new Image(MatchFile.toURI().toString());
        MatchIMG.setImage(MatchIcon);
        
       
        UserIMG.setImage(UserIcon);
        
         File NewsFile = new File("image/NewsTXT.png");
        Image NewsIcon = new Image(NewsFile.toURI().toString());
        NewsIMG.setImage(NewsIcon);
        
         File EventFile = new File("image/EventTXT.png");
        Image EventIcon = new Image(EventFile.toURI().toString());
        EventIMG.setImage(EventIcon);
        
        File RecFile = new File("image/RecTXT.png");
        Image RecIcon = new Image(RecFile.toURI().toString());
        RecIMG.setImage(RecIcon);
        
        File TerrainFile = new File("image/Terrain.png");
        Image TerrainIcon = new Image(TerrainFile.toURI().toString());
        TerrainIMG.setImage(TerrainIcon);
        
        File CoachFile = new File("image/CoachIcon.png");
        Image CoachIcon = new Image(CoachFile.toURI().toString());
        CoachIMG.setImage(CoachIcon);
        
        File ArbitreFile = new File("image/ArbitreIcon.png");
        Image ArbitreIcon = new Image(ArbitreFile.toURI().toString());
        ArbitreIMG.setImage(ArbitreIcon);
        
        File GymFile = new File("image/GymIcon.png");
        Image GymIcon = new Image(GymFile.toURI().toString());
        GymIMG.setImage(GymIcon);
        //
        
         af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id_m"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
 af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
  af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
   af_text.setCellValueFactory(new PropertyValueFactory<>("image"));
  

   listM=MaConnexion.getDatamatch();
   table_match.setItems(listM);

     listArbitre=MaConnexion.getDataParticipant2();
     combobox.setItems(listArbitre);
    
        
        
                System.out.println("bb");    

        // TODO
    } 
   
     ObservableList optionsList=FXCollections.observableArrayList();

    @FXML
    private void ajouter_match(ActionEvent event) throws FileNotFoundException {
        if(valide() ){
       
        Servicematch sp=new Servicematch();
       Match m=new Match();
       Serviceparticipant sps=new Serviceparticipant();
       Participant p=new Participant();
       
        
      m.setEquipeA(tf_equipe1.getText());
         m.setEquipeB(tf_equipe2.getText());
          m.setDate(Date.valueOf(tf_date2.getValue()));
          m.setTour(text_tour.getText());
           m.setImage(aff.getText());
           //p.setNom((String) combobox.getSelectionModel().getSelectedItem());
       
             
             
             
       
         
          
         
        
        sp.ajouter_match(m);
        update();
       
          
    
        
    }}


    @FXML
    private void supprimer_match(ActionEvent event) {
        
        
        try{  String req = "DELETE FROM `match` WHERE id_m=?";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
            pst.setString(1, tf_id.getText());

pst.execute();
        
        
        
         ObservableList<Match> evenements, SingleEvenements;
       evenements=table_match.getItems();
       SingleEvenements=table_match.getSelectionModel().getSelectedItems();
  SingleEvenements.forEach(evenements::remove); 
    
        }
          catch (SQLException e) {JOptionPane.showMessageDialog(null, e);
        System.out.println("supprime");
        }}
     

    
    
   
  
  
    @FXML
   private void filtrer(ActionEvent event) {
        
        
   af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id_m"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
 af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
  af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
  af_text.setCellValueFactory(new PropertyValueFactory<>("image"));
   
 
   DataList=MaConnexion.getDatamatch();
 table_match.setItems(DataList);
        FilteredList<Match> filteredDatamatch=new FilteredList<>(DataList,b->true);
         tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredDatamatch.setPredicate(Match -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
   
    if (Match.getEquipeA().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches nom
  
    }else if (Match.getEquipeB().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
     
    
     }else if (Match.getTour().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
     }else if (Match.getImage().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; 
    }   else  
          return false; // Does not match.
   });
  });  
  SortedList<Match> sortedData = new SortedList<>(filteredDatamatch);  
  sortedData.comparatorProperty().bind(table_match.comparatorProperty());  
  table_match.setItems(sortedData); 


        
       
        
        
    
   
   
  

           
           
       
       
   }

       
          private void update(){
      af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id_m"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
  af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
   af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
    // af_text.setCellValueFactory(new PropertyValueFactory<>("image"));
   
   listM=MaConnexion.getDatamatch();
  table_match.setItems(listM);
    }  
        
      @FXML
    private void Select(javafx.scene.input.MouseEvent event) {
      
       
        index =table_match.getSelectionModel().getSelectedIndex();
        if (index<=-1){
            return;
    }
    tf_id.setText(af_id.getCellData(index).toString());
     tf_equipe1.setText(af_equipe1.getCellData(index));
       tf_equipe2.setText(af_equipe2.getCellData(index));
        text_tour.setText(af_tour.getCellData(index));
         //text.setText(af_text.getCellData(index));
           aff.setText(af_text.getCellData(index));
          String affi = aff.getText();
                File file = new File(affi);
                
            lmatch.setImage(new javafx.scene.image.Image(file.toURI().toString()));
 
   
        

       
    }   

    @FXML
    private void edit(ActionEvent event) {
       
            try {String v1=tf_id.getText();
           String v2=tf_equipe1.getText();
           String v3=tf_equipe2.getText();
                      String v5=text_tour.getText();
                       String v6=aff.getText();

     String req = "UPDATE `match` set id_m= '"+v1+"',`equipeA`= '"+v2+"',`equipeB`= '"+
                    v3+"',`tour`='"+v5+"',`image`='"+v6+"' where id_m= '"+v1+"' ";
PreparedStatement pst=MaConnexion.getInstance().getConnection().prepareStatement(req);
pst.executeUpdate();
               update();
            JOptionPane.showMessageDialog(null, "update");
           } catch (SQLException e) {JOptionPane.showMessageDialog(null, e);
           System.out.println("edit");
        }}
    
  
  
  
  
  
     private boolean valide()
    {if(tf_equipe1.getText().isEmpty()|tf_equipe2.getText().isEmpty()|text_tour.getText().isEmpty())
    {Alert alert= new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("match reconnu");
        alert.setHeaderText(null);
        alert.setContentText("champ vide!!");
        alert.showAndWait();
    return false;}
    return true;}
    
    
 
    @FXML
    private void perfermance(ActionEvent event) {
    
          FileChooser fe = new FileChooser();

        fe.setTitle("image chooser");
        fe.setInitialDirectory(new File(System.getProperty("user.home")));
        fe.getExtensionFilters().clear();
        fe.getExtensionFilters().add(new FileChooser.ExtensionFilter("image file", "*.jpeg", "*.png", "*.gif"));
        File file = fe.showOpenDialog(null);
        aff.appendText(file.getAbsolutePath());
        if (file != null) {
            lmatch.setImage(new javafx.scene.image.Image(file.toURI().toString()));
        } else {
            System.out.println("a file is invalide");
        }
      
    }   
      private void combobox(){
             try {        String requete="SELECT nom FROM `Arbitre`,match where date=date_Arbitre";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
               optionsList.add(rst.getString("nom"));
              
               
           }
           pst.close();
           rst.close();
             }catch (SQLException ex){
                 
                    System.out.println("combobox!!!!!!!");
      }
      }



    @FXML
    
    private void action(ActionEvent event) {
        
        String s =combobox.getSelectionModel().getSelectedItem().toString();
        
    }


    @FXML
    private void hand(ActionEvent event) {
      
        System.out.println("click");
        Notifications.create().title("envoyé pour le jour du match")
                .text("cest le jourx").darkStyle().position(Pos.TOP_LEFT)
                .showWarning();
        
       
        
    }

    @FXML
    private void statiqtique(ActionEvent event) throws IOException {
        
         
        FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("/pijava/stat.fxml"));
                        try {
                            loader.load();
                           
                              } catch (IOException ex) {
                            Logger.getLogger(MatchController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        Parent parent = loader.getRoot();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(parent));
                        stage.show();
        
        
    }

    
    

  

    

    @FXML
    private void GoToparticipant(ActionEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("/pijava/participant/FXMLDocument.fxml"));
    Stage window= (Stage) goParticipant.getScene().getWindow();
    window.setScene(new Scene(root));
    }
    
    @FXML
    private void UserControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminUser/BackUserList.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void RecControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/AdminReclamation/BackReclamation.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void DashboardOnAction(ActionEvent event) {
            // direction interface admin 
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader ();
        loader.setLocation(getClass().getResource("/pijava/AdminInterface/AdminInterface.fxml"));
        try {
        loader.load();


        } catch (IOException ex) {
        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("failed to load");
        System.out.println(ex);
        }
        Parent parent = loader.getRoot();
        stage.setScene(new Scene(parent));
        stage.show();
    }

    @FXML
    private void CoachControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/CoachBack/BackMenuCoach.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void NewsControlOnAction(ActionEvent event) {
        Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/NewsCom/FXMLNews0.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(MatchController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

     @FXML
    private void MatchControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/match/match.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void EventControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/evenement/evenement.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void ArbitreControlOnAction(ActionEvent event) {
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/arbitre/Arbitre.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

    @FXML
    private void TerrControlOnAction(ActionEvent event) {
          Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Terrain/Terrain.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(AdminInterfaceController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
            
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }

}




    
    
    





 



      

        
    




  
    
    
    
    
          
 



    

    


     
          
       
       

          
     
     
     
     
     
     
        
    
     
   


  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
       

          
     
     
     
     
     
     
        
    
     
   


  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
    
    
    
    
    
    
    


