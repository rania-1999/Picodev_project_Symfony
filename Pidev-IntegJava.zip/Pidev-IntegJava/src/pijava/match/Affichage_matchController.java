/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.match;
// affichage pour utilisateur
import entite.Arbitre;
import entite.Match;
import entite.Participant;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import Utils.MaConnexion;
import entite.Match;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import pijava.UsersFront.UsersListController;

/**
 * FXML Controller class
 *
 * @author Bechir
 */
public class Affichage_matchController implements Initializable {

  
    @FXML
    private TableColumn<Match, String> af_equipe1;
    @FXML
    private TableColumn<Match, String> af_equipe2;
    @FXML
    private TableColumn<Match, String> af_date;
    @FXML
    private TableColumn<Match, String> af_tour;
   
    
  ObservableList<Match> listM;
       ObservableList<Match> DataList;
        ObservableList<Arbitre> listArbitre;
    String s;
    
    @FXML
    private TableView<Match> table_match1;
    @FXML
    private ComboBox combobox;
    @FXML
    private TextField tf_combo;
    @FXML
    private Button participer;
    @FXML
    private Button affp;
    @FXML
    private ImageView LogoIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameHOME;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
         
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
 af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
  af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
   
  
    
   listM=MaConnexion.getDatamatch2();
   table_match1.setItems(listM);
    listArbitre=MaConnexion.getDataParticipant2();
   
         combobox.setItems(listArbitre);

    
        
        
      
        
        // TODO
    }    

    @FXML
    private void Select(MouseEvent event) {
    }
    ObservableList optionsList=FXCollections.observableArrayList();
      private void combobox(){
             try {        String requete="SELECT  * FROM  `match`";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
               optionsList.add(rst.getString("equipeA"));
              
               
           }
           pst.close();
           rst.close();
             }catch (SQLException ex){
                 
                    System.out.println("combobox!!!!!!!");
      }
      }

    @FXML
    private void action(ActionEvent event) {
         String s =combobox.getSelectionModel().getSelectedItem().toString();
        tf_combo.setText(s);
    }

    @FXML
    private void participe(ActionEvent event) throws IOException {
         Parent root = FXMLLoader.load(getClass().getResource("formulaireMatch.fxml"));
    Stage window= (Stage) participer.getScene().getWindow();
    window.setScene(new Scene(root));
    }

   

    

    @FXML
    private void afficherParticipant(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("afficage_paricipant.fxml"));
    Stage window= (Stage) affp.getScene().getWindow();
    window.setScene(new Scene(root));
    }

    @FXML
    private void RetourOnAction(ActionEvent event) {
        
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Login/Accueil.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(UsersListController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
    }
    
}
