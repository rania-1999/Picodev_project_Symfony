/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pijava.match;
//formulaire pour utilisateur
import entite.Arbitre;
import entite.Evenement;
import entite.Match;
import entite.Participant;
import java.io.IOException;
import java.net.URL;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import serviceclass.Servicematch;
import serviceclass.Serviceparticipant;
import Utils.MaConnexion;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Node;
import pijava.UsersFront.UsersListController;

/**
 * FXML Controller class
 *
 * @author rania arafa
 */
public class FormulaireMatchController implements Initializable {

    private Button goMatch;
    private Button goEvenement;
    private Button goArbitre;
    @FXML
    private TextField nomp;
    @FXML
    private TextField prenomp;
    @FXML
    private ComboBox datep;

    /**
     * Initializes the controller class.
     */
        ObservableList<Match> listA;
    @FXML
    private Label combo;
    @FXML
    private ImageView LogoIMG;
    @FXML
    private ImageView ProfilIMG;
    @FXML
    private Label UsernameHOME;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         listA = MaConnexion.getDataDate();
     datep.setItems(listA);
    }    


    


    @FXML
    private void ajouterP(ActionEvent event) {
 
       Serviceparticipant sps=new Serviceparticipant();
       Participant p=new Participant();
       Match ma=new Match();
        
      p.setNom(nomp.getText());
         p.setPrenom(prenomp.getText());
         sps.ajouter_participantm(p);
         System.out.println("click");
        Notifications.create().title("félicitation ")
                .text("vous participerez a ce match ").darkStyle().position(Pos.TOP_LEFT)
                .showWarning();
        Arbitre a= new Arbitre();
        Evenement e=new Evenement();
        Match m=new Match();
        
        try {
            String requete = "INSERT INTO gestion (ide,ida,idm,idp )"
                    + "VALUES ('"+e.getId_evenement()+"','"+a.getId()+"','"+m.getId_m()+"','"+p.getId()+"'')";
            Statement st = MaConnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Arbitre ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
   
    @FXML
    private void select_date(ActionEvent event) {
          Serviceparticipant sps=new Serviceparticipant();
       Participant p=new Participant();

    String m=datep.getSelectionModel().getSelectedItem().toString();
    combo.setText(m);
    
        
}

    @FXML
    private void RetourOnAction(ActionEvent event) {
        
         Node node = (Node) event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader ();
                loader.setLocation(getClass().getResource("/pijava/Login/Accueil.fxml"));
                try {
                        loader.load();
                        
                        
                    } catch (IOException ex) {
                        Logger.getLogger(UsersListController.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("failed to load");
                        System.out.println(ex);
                    }
                    Parent parent = loader.getRoot();
                    stage.setScene(new Scene(parent));
                    stage.show(); 
        
    }
}
