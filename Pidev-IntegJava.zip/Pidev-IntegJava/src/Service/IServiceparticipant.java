/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

/**
 *
 * @author Bechir
 */
import entite.Participant;
import java.sql.SQLException;
import java.util.List;


/**
 *
 * @author Bechir
 */
public interface IServiceparticipant {
    
    public void ajouter_participant (Participant p);
    public List <Participant> affichage_participant() ;
    public void ajouter_participantm (Participant p);
     public void supprimerparticipant(Participant p);
     public void updateparticipant(Participant p);
    
}