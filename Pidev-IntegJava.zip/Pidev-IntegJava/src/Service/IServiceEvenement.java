/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import entite.Evenement;
import java.util.List;
import javafx.collections.ObservableList;

/**
 *
 * @author rania arafa
 */
public interface IServiceEvenement {
    public  void AjouterEvenement (Evenement e);
    public List <Evenement> AfficherEvenement(); 
         public void supprimerEvenement(Evenement e);
    public void updateEvenement(Evenement e);

}
