/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

/**
 *
 * @author Bechir
 */
import entite.Match;
import entite.Participant;
import java.sql.SQLException;
import java.util.List;


/**
 *
 * @author Bechir
 */
public interface IServicematch {
    
    public void ajouter_match (Match m);
    public List <Match> affichage_match() ;
        public void ajouter_matchp (Match m);

     public void supprimer_match(Match m);
     public void updatematch(Match m);
    
}