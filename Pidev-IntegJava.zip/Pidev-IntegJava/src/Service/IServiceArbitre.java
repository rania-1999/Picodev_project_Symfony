/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import entite.Arbitre;
import java.util.List;

/**
 *
 * @author rania arafa
 */
public interface IServiceArbitre {
       public  void AjouterArbitre (Arbitre a);
    public List <Arbitre> AfficherArbitre(); 
         public void supprimerArbitre(Arbitre a);
  //  public void updateArbitre(Arbitre a);
}
