/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.Commentaire;
import Entities.News;
import Entities.Utilisateur;
import Services.InterfaceServicesCommentaires;
import Utils.MaConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author guest
 */
public class ServiceCommentaires implements InterfaceServicesCommentaires {
         Connection cnx;
    public ServiceCommentaires() {
        cnx=MaConnexion.getInstance().getConnection();
    }
    @Override
    public void AjouterCommentaire(Commentaire c,int idN) {
        try {
            Statement stm =cnx.createStatement();
            String query="INSERT INTO `commentaire`(`Contenu`, `dateCommentaire`,`idNews`,`idUtilisateur`) VALUES ("+'"'+c.getContenu()+'"'+","+'"'+c.getDate_dajout()+'"'
                  +","+'"'+idN+'"' +","+'"'+c.getUtilisateur().getId()+'"'+")";
            System.out.println(query);
           
            stm.executeUpdate(query);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
   
    }
    @Override
    public ObservableList<Commentaire> AfficherCommentaire(int idN) {
         ServiceUtilisateur se=new ServiceUtilisateur();
       
            ObservableList<Commentaire> Commentaires = FXCollections.observableArrayList();

        try {
            Statement stm =cnx.createStatement();
//           
            String query="SELECT * FROM commentaire where idNews="+idN;
            System.out.println(query);
            ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {
                Commentaire c = new Commentaire();
                c.setId(rst.getInt("idCommentaire"));
                c.setContenu(rst.getString("Contenu"));
                c.setDate_dajout(rst.getDate("dateCommentaire"));
                c.setUtilisateur(se.UserById(rst.getInt("idUtilisateur")));
                Commentaires.add(c);
                
              
                
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            return Commentaires;
    }
    

    @Override
    public void SupprimerCommentaire(Commentaire c) {
             try {
                 String query = "delete from `commentaire` where `idCommentaire`="+c.getId();
                 PreparedStatement pst = cnx.prepareStatement(query);
                 pst.execute();
             } catch (SQLException ex) {
                 System.out.println(ex.getMessage());
             }
    }

    @Override
    public void ModifierCommentaire(Commentaire c) {
             try {
                 String query = "UPDATE `commentaire` SET `Contenu`= '"+c.getContenu()+"' WHERE idCommentaire="+c.getId();
                 
                 PreparedStatement pst = cnx.prepareStatement(query);
                 pst.execute();
             } catch (SQLException ex) {
                 System.out.println(ex.getMessage());
             }
    }

  
    public Commentaire getCommentaire(int id){
                 ServiceUtilisateur se=new ServiceUtilisateur();
       
            Commentaire Commentaires = new Commentaire();

        try {
            Statement stm =cnx.createStatement();
//           
            String query="SELECT * FROM commentaire where idCommentaire="+id;
            System.out.println(query);
            ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {
                Commentaire c = new Commentaire();
                c.setId(rst.getInt("idCommentaire"));
                c.setContenu(rst.getString("Contenu"));
                c.setDate_dajout(rst.getDate("dateCommentaire"));
                c.setUtilisateur(se.UserById(rst.getInt("idUtilisateur")));
                Commentaires=c;
                
              
                
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            return Commentaires;
    }
}
