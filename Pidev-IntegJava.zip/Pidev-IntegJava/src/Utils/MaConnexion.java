/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import entite.Arbitre;
import entite.Evenement;
import entite.Match;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import entite.Participant;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.collections.ObservableMap;
import static jdk.nashorn.internal.runtime.Debug.id;

/**
 *
 * @author Bechir
 */
public class MaConnexion {
    final static String url ="jdbc:mysql://127.0.0.1:3306/pidev";
    final static String LOGIN ="root";
    final static String PASSWORD="";
    static MaConnexion  instance = null;
     private Connection cnx ;
     
     private MaConnexion(){
        try {
            cnx= DriverManager.getConnection(url,LOGIN,PASSWORD);
            System.out.println("Connexion établie");
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            System.out.println("pas de connexion");        }}
        
        public static MaConnexion getInstance(){
            
            if (instance==null){
                
                    instance = new MaConnexion();
        }
            return instance;
            
            
        }
        public Connection getConnection(){
            return cnx;
            
        }
 



public static ObservableList<Participant> getDataParticipant()
    {
       
        ObservableList<Participant> list=FXCollections.observableArrayList();
   try{String requete = "select * from participant";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Participant(rs.getInt("id"), rs.getString("nom"),rs.getString("prenom")));
       }
   
   }catch (SQLException e){ System.out.println("non liste participant");}
       
        return list;
    }
public static ObservableList<Arbitre> getDataParticipant2()
    {
       
        ObservableList<Arbitre> listaArbitre=FXCollections.observableArrayList();
   try{String requete = "SELECT `nom` FROM `match`,`arbitre`WHERE arbitre.date_arbitre=match.date ";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
listaArbitre.add(new Arbitre( rs.getString("nom")));
       }
   
   }catch (SQLException e){ System.out.println("non liste participant");}
       
        return listaArbitre;
    }
   



public static Match getmatch(int id_m) {
        Match m=new Match();
        
                 try {        String requete="SELECT `id_m`,`equipeA`,`equipeB`, `date`, `tour`, `image`, `nom` from  `match` where id_m=?";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id_m);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(2, m.getEquipeA());
         
  pst.setInt(1, m.getId_m());
            pst.setString(3, m.getEquipeB());
            pst.setDate(4, m.getDate());
            pst.setString(5, m.getTour());
            pst.setString(6, m.getImage());
            
                   
           }
            System.out.println("match modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return m;
        
    }
public static Match getmatch2(int id_m) {
        Match m=new Match();
        
                 try {        String requete="SELECT `id_m`,`equipeA`,`equipeB`, `date`, `tour`, `image`, `nom` from  `match` where id_m=?";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id_m);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(2, m.getEquipeA());
         
  pst.setInt(1, m.getId_m());
            pst.setString(3, m.getEquipeB());
            pst.setDate(4, m.getDate());
            pst.setString(5, m.getTour());
            pst.setString(6, m.getImage());
            
                   
           }
            System.out.println("match modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return m;
        
    }


    
   /*public static ObservableList<Match> getDatamatch()
    {
       
        ObservableList<Match > list=FXCollections.observableArrayList();
   try{String requete = "SELECT `id_m`,`equipeA`,`equipeB`, `date`, `tour`, `image`, `nom` from  `match`, `participant`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Match(rs.getInt("id_m"),rs.getString("equipeA"),rs.getString("equipeB"),rs.getDate("date"),rs.getString("tour"),rs.getString("image") ));
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
       
        return list;
    }*/
   public static ObservableList<Match> getDatamatch()
    {
       
        ObservableList<Match > list=FXCollections.observableArrayList();
   try{String requete = "SELECT `id_m`, `equipeA`, `equipeB`, `date`, `tour`, `image` FROM `match`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Match(rs.getInt("id_m"),rs.getString("equipeA"),rs.getString("equipeB"),rs.getDate("date"),rs.getString("tour"),rs.getString("image") ));
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
       
        return list;
    }
   
 public static Participant getParticipantID(int id) {
        Participant e=new Participant();
        
                 try {        String requete="select * from participant where id=?";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(1, e.getNom());
         
  pst.setInt(2, e.getId());
            pst.setString(3, e.getPrenom());
           }
            System.out.println("participant  modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return e;
        
    }
    public static ObservableList<Evenement> getDataevenements()
    {
       
        ObservableList<Evenement> list=FXCollections.observableArrayList();
   try{String requete = "SELECT  * FROM `evenement`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Evenement(rs.getInt("id_evenement"), rs.getString("nom_evenement"),rs.getString("descrip_evenement"),rs.getDate("date_evenement")) );
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
        
        return list;
    }
   public static Evenement getEvenementID(int id_evenement) {
        Evenement e=new Evenement();
        
                 try {        String requete="select * from evenement where id_evenement=?";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id_evenement);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(1, e.getNom_evenement());
            pst.setInt(2, e.getId_evenement());
            pst.setString(3, e.getDescrip_evenement());
            pst.setDate(4, e.getDate_evenement());
           }
            System.out.println("evenement  modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return e;
        
    }
    public static ObservableList<Match> getDatamatch2()
    {
       
        ObservableList<Match > list=FXCollections.observableArrayList();
   try{String requete = "SELECT `equipeA`,`equipeB`, `date`, `tour` from  `match`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Match(rs.getString("equipeA"),rs.getString("equipeB"),rs.getDate("date"),rs.getString("tour") ));
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
       
        return list;
    }
   
   
    public static ObservableList<Arbitre> getDataarbitres()
    {
       
        ObservableList<Arbitre> list=FXCollections.observableArrayList();
   try{String requete = "select * from arbitre  ORDER BY `arbitre`.`nom` ASC";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Arbitre(rs.getInt("id"), rs.getString("nom"),rs.getString("prenom"),rs.getString("filiere"),rs.getString("image"),rs.getString("disponibilite"),rs.getDate("date_arbitre")));
       }
   
   }catch (SQLException e){ System.out.println("non");}
        
        return list;
        }
     public static Arbitre getArbitreID(int id) {
        Arbitre a=new Arbitre();
        
                 try {        String requete="select * from arbitre where id=?";

            PreparedStatement pst = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(1, a.getNom());
            pst.setInt(2, a.getId());
            pst.setString(3, a.getPrenom());
                        pst.setString(4, a.getFiliere());
                 pst.setString(5, a.getImage());
  pst.setString(6, a.getDisponiblite());
  pst.setDate(7, (Date) a.getDate_arbitre());
           }
            System.out.println("arbitre  modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return a;
        
    }

       public static ObservableList getDataNomArbitres() {
       
        ObservableList<Arbitre> list=FXCollections.observableArrayList();
   try{String requete = "select nom from arbitre";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Arbitre( rs.getString("nom")) );
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
        
        return list;
    }
           public static ObservableList<Evenement> getDataevenementsU()
    {
       
        ObservableList<Evenement> list=FXCollections.observableArrayList();
   try{String requete = "SELECT  nom_evenement, descrip_evenement,date_evenement FROM `evenement`";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Evenement( rs.getString("nom_evenement"),rs.getString("descrip_evenement"),rs.getDate("date_evenement")) );
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
        
        return list;
    } 
        public static ObservableList<Match> getDataDate()
    {
       
        ObservableList<Match> listdate=FXCollections.observableArrayList();
   try{String requete = "SELECT `date` FROM `match` ";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
listdate.add(new Match( rs.getDate("date")));
       }
   
   }catch (SQLException e){ System.out.println("non liste participant");}
       
        return listdate;
    }
   
 public static ObservableList<Evenement> getDataDateEvenements()
    {Evenement e=new  Evenement();
       
        ObservableList<Evenement> listdate=FXCollections.observableArrayList();
   try{String requete = "SELECT `nom_evenement` FROM `evenement` ";
            PreparedStatement ps = MaConnexion.getInstance().getConnection()
                    .prepareStatement(requete);

       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
listdate.add(new Evenement( rs.getString("nom_evenement")));

       }
   
   }catch (SQLException ex){ System.out.println("non liste evenement");}
       
        return listdate;
    }

}
    
       
    
    
       


    


