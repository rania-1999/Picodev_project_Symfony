/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



package entite;

import java.text.*;
import javafx.scene.control.TableView;
import javax.swing.*;




/**
 *
 * @author Bechir
 */
public class driver {
    
    public static void imprimerJtable(JTable jt,String titre){
        
     MessageFormat entete =new MessageFormat(titre);
     MessageFormat pied =new MessageFormat("Page {0,number,integer}");
        try {
            
            jt.print(JTable.PrintMode.FIT_WIDTH,entete,pied);
            
            
            
            
            
            
        } catch (Exception e) {
        }
        
        
    }

    public static void imprimerJtable(TableView<Match> table_match, String titre) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
