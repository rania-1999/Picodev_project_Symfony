/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.sql.Date;

/**
 *
 * @author Bechir
 */
public class Match {
    private int id_m;
    private String equipeA,equipeB;
    private Date date;
    private String tour;
    private String image;

    public Match(int id_m, String equipeA, String equipeB, Date date, String tour, String image) {
        this.id_m = id_m;
        this.equipeA = equipeA;
        this.equipeB = equipeB;
        this.date = date;
        this.tour = tour;
        this.image = image;
    }

    public Match(Date date) {
        this.date = date;
    }

    public Match(String equipeA, String equipeB, Date date, String tour) {
        this.equipeA = equipeA;
        this.equipeB = equipeB;
        this.date = date;
        this.tour = tour;
    }
    

   
    

   
    
    
    public int getId_m() {
        return id_m;
    }

    public String getEquipeA() {
        return equipeA;
    }

    public String getEquipeB() {
        return equipeB;
    }

    public Date getDate() {
        return date;
    }

    public String getTour() {
        return tour;
    }
     public String getImage() {
        return image;
    }

    public void setId_m(int id_m) {
        this.id_m = id_m;
    }

    public void setEquipeA(String equipeA) {
        this.equipeA = equipeA;
    }

    public void setEquipeB(String equipeB) {
        this.equipeB = equipeB;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setTour(String tour) {
        this.tour = tour;
    }
public void setImage(String image) {
        this.image = image;
    }
    public Match() {
    }

     public Match(int id_m, String EquipeA, String equipeB, Date date, String tour ) {
        this.id_m = id_m;
        this.equipeA = EquipeA;
        this.equipeB = equipeB;
        this.date = date;
        this.tour = tour;
       
    }

    
   /* public String toString() {
        return "Match{" + "equipeA=" + equipeA + '}';
    }*/

    @Override
    public String toString() {
        return "Match{" + "date=" + date + '}';
    }

   
   
      

 
    
    
    
    
    
    
    
    
}
