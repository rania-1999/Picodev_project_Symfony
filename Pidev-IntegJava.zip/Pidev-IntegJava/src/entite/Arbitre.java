/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.sql.Blob;
import java.util.Date;
import java.util.logging.Logger;


/**
 *
 * @author rania arafa
 */
public class Arbitre {
       private int id;
    private String nom;
    private String prenom;
    private String filiere;
   private String image;
   private String disponiblite;
   private Date date_arbitre;

    public Date getDate_arbitre() {
        return date_arbitre;
    }

    public Arbitre(int id, String nom, String prenom, String filiere, String image, String disponiblite, Date date_arbitre) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.filiere = filiere;
        this.image = image;
        this.disponiblite = disponiblite;
        this.date_arbitre = date_arbitre;
    }

    public void setDate_arbitre(Date date_arbitre) {
        this.date_arbitre = date_arbitre;
    }

    public Arbitre(int id, String nom, String prenom, String filiere, String image, String disponiblite) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.filiere = filiere;
        this.image = image;
        this.disponiblite = disponiblite;
    }

    public String getDisponiblite() {
        return disponiblite;
    }

    public void setDisponiblite(String disponiblite) {
        this.disponiblite = disponiblite;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Arbitre(int id, String nom, String prenom, String filiere, String image) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.filiere = filiere;
        this.image = image;
    }

    public Arbitre(String nom) {
        this.nom = nom;
    }

    @Override
    public String toString() {
        return nom ;
    }

 

  
   

  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public Arbitre() {
    }

    public Arbitre(int id, String nom, String prenom, String filiere) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.filiere = filiere;
    }
    
    
}
