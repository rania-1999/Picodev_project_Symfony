/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import java.sql.Date;

/**
 *
 * @author rania arafa
 */
public class Evenement {
    private int id_evenement;
    private String nom_evenement;
    private String descrip_evenement;
private Date date_evenement;

    public Evenement(int id_evenement, String nom_evenement, String descrip_evenement, Date date_evenement) {
        this.id_evenement = id_evenement;
        this.nom_evenement = nom_evenement;
        this.descrip_evenement = descrip_evenement;
        this.date_evenement = date_evenement;
    }

    public Evenement(int id_evenement, String nom_evenement) {
        this.id_evenement = id_evenement;
        this.nom_evenement = nom_evenement;
    }

    public Evenement(String nom_evenement, String descrip_evenement, Date date_evenement) {
        this.nom_evenement = nom_evenement;
        this.descrip_evenement = descrip_evenement;
        this.date_evenement = date_evenement;
    }



 

    public Date getDate_evenement() {
        return date_evenement;
    }

    public void setDate_evenement(Date date_evenement) {
        this.date_evenement = date_evenement;
    }

    public Evenement() {
    }

   

    public int getId_evenement() {
        return id_evenement;
    }

    public String getNom_evenement() {
        return nom_evenement;
    }

    public String getDescrip_evenement() {
        return descrip_evenement;
    }

    public void setId_evenement(int id_evenement) {
        this.id_evenement = id_evenement;
    }

    public void setNom_evenement(String nom_evenement) {
        this.nom_evenement = nom_evenement;
    }

    public void setDescrip_evenement(String descrip_evenement) {
        this.descrip_evenement = descrip_evenement;
    }

   

    @Override
    public String toString() {
        return nom_evenement ;
    }

    public Evenement(String nom_evenement) {
        this.nom_evenement = nom_evenement;
    }

   
 
    

    public Evenement(Date date_evenement) {
        this.date_evenement = date_evenement;
    }

   
    
}
